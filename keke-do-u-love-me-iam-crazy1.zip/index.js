const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Hello Express app!')
});

app.listen(3000, () => {
  console.log('LuckyBet By MimoXL');
});
const line = "https://media.discordapp.net/attachments/1175077829038313522/1218677583420457101/20240316_233732.png?ex=660888f1&is=65f613f1&hm=4097d968338f9737e65f76a06d20131a67f84be6853a87ff657ef84b0df07b6e&=&format=webp&quality=lossless&width=1025&height=40"
const applycategory = "1251649131320180868";
const applycatagory = "1251649131320180868";
const redemcode = "1217125242887999631";
const Discord = require("discord.js")
const db = require("./models/databaseusers")
const game = require("./models_games/game")
const nrd = require("./models_games/nrd")
const nrdusr = require("./models_games/nrdusergame")
const takribi = require("./models_games/takribi")
const tkusr = require("./models_games/takribiusergame")
const Data = require('./models_games/info')
const config = require('./config.json')
const client = new Discord.Client({ intents: 32767 })
const Mongoose = require('mongoose')
var _0x81bd = ["\x6D\x6F\x6E\x67\x6F\x6F\x73\x65"]; const mongoose = require(_0x81bd[0])
const _0x8467 = ["mongodb+srv://Cluster1:NFkTaZys2sPi3nLL@pluplus1.gmaaf5r.mongodb.net/", "connect"]; mongoose[_0x8467[1]](_0x8467[0])
const { Client, Collection , MessageActionRow , MessageButton , MessageSelectMenu , Modal , TextInputComponent , ActionRowBuilder , TextInputStyle , TextInputBuilder , ModalBuilder , MessageEmbed, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, row } = require('discord.js')
    const timestamp = require('discord-timestamp');
  const moment = require("moment")
  const ms = require('ms');
  const tax = require('probot-tax-calculator')
var welcome = "1217125298383093792"
  let ownertr = "627553422186512384"
  let probotId = "282859044593598464"

  let owners = ["627553422186512384", "627553422186512384", "627553422186512384", "627553422186512384"]


  client.on("ready", async () => {
    console.log(`${client.user.tag} IS Ready!`)
  })

 client.on("ready", () => {
   console.log(`${client.user.tag}`);
   client.user.setStatus("online");
   let status = [
     `Subscribe To Server`,
   ];
   setInterval(() => {
     client.user.setActivity(status[Math.floor(Math.random() * status.length)]);
   }, 5000);
 });


  const { Probot } = require("discord-probot-transfer");
  client.probot = Probot(client, {
    fetchGuilds: true,
    data: [
      {
        fetchMembers: true,
        guildId: "768512875575640094",
        probotId: "282859044593598464",
        owners: ["627553422186512384"],
      },
    ],
  });









client.on('messageCreate', async (message) => {
    if (message.content.startsWith('file') || message.content.startsWith('ملف')) {
        const user = message.mentions.members.first() || message.author;
        const userData = await Data.findOne({ _id: user.id });
        const embed = new Discord.MessageEmbed()
            .setTitle(`${user.user?.username || message.author.username} الملف الشخصي لـ`)
            .setColor('BLUERPLE').setThumbnail(user.avatarURL({ dynamic: true }))
            .setFooter(message.guild.name)
            .setTimestamp()
            .addFields(
                { name: ' عدد التحديات'   , value: ` >  \`${userData?.t || '0'}\`` },
                { name: ' عدد مرات الفوز'   , value: ` >  \`${userData?.f || '0'}\``,inline: true },
                { name: ' عدد مرات الخسارة'   , value: ` >  \`${userData?.k || '0'}\``,inline: true },
                { name: '   عدد مرات التعادل'   , value: ` > \`${userData?.t1 || '0'}\``,inline: true },
                 { name: ' اجمالي الربح'   , value: ` > \`${userData?.a || '0'}\`` ,inline: true},
                  { name: ' اجمالي السحب'   , value: ` > \`${userData?.u || '0'}\``,inline: true },
                { name: ' اجمالي الخسارة'   , value: ` > \`${userData?.c || '0'}\``,inline: true },
                { name: ' التحويلات الواردة   '   , value: ` > \`${userData?.w || '0'}\``,inline: true},
                { name: ' التحويلات الصادرة'   , value: ` > \`${userData?.s || '0'}\``,inline: true },
                   { name: ' المستوى   '   , value: ` > \`${userData?.s5 || '0'}\``,inline: true },
                    { name: 'الاكسبي   '   , value: ` >  \`${userData?.s5 || '0'}\``,inline: true },
              );

        message.reply({ content: `> ${user}`, embeds: [embed] });
    }
});
  client.on("ready", async () => {
    setInterval(async () => {
      let es = (await game.find())
      es.forEach(async d => {
        let time = await d.time
        if (!time) return;

        if (time == timestamp(moment(Date.now())) || time < timestamp(moment(Date.now()))) {
          let ndata = await nrd.findOne({
            idstusr: d.id,
            msgID: d.msgID
          })
          let tkdata = await takribi.findOne({
            idstusr: d.id,
            msgID: d.msgID
          })
          if (ndata) {
            let gdata = await game.findOne({
              id: d.id,
              with: d.with,
              msgID: d.msgID
            })
            let st1usrrr = client.users.cache.get(ndata.notrole)
            let st2usrrr = client.users.cache.get(ndata.role)
            let userr1r = await nrdusr.findOne({
              id: st1usrrr.id
            })
            let userr2r = await nrdusr.findOne({
              id: st2usrrr.id
            })
            client.channels.cache.get(gdata.channelID).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
              content: `بسبب الخمول لقد فاز ${st1usrrr} بمجموع \`${userr1r.result || 0}\`

    لقد خسر ${st2usrrr} بمجموع \`${userr2r.result || 0}\`

    > || ${st1usrrr} | ${st2usrrr} ||`, components: [],
            })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: st1usrrr.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: st1usrrr.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: st2usrrr.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr2st = await db.create({
                id: st2usrrr.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await nrd.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: d.id
            })
            await nrdusr.findOneAndDelete({
              id: st1usrrr.id
            })
            await nrdusr.findOneAndDelete({
              id: st2usrrr.id
            })
            await game.findOneAndDelete({
              id: d.id,
              with: d.with,
              msgID: d.msgID
            })
          }
          if (tkdata) {
            let gdata = await game.findOne({
              id: d.id,
              with: d.with,
              msgID: d.msgID
            })
            let st1usrrr = client.users.cache.get(tkdata.notrole)
            let st2usrrr = client.users.cache.get(tkdata.role)
            let stusrgame = client.users.cache.get(gdata.id)
            let wthusrgame = client.users.cache.get(gdata.with)
            let userr1r = await tkusr.findOne({
              id: st1usrrr.id
            })
            let userr2r = await tkusr.findOne({
              id: st2usrrr.id
            })
            if (!userr1r) return;
            if (!userr2r) return;
            let embed = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${tkdata.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${userr1r.numbers.join(" + ") || ""} = **${userr1r.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${userr2r.numbers.join(" + ") || ""} = **${userr2r.result || 0}**` })
            client.channels.cache.get(gdata.channelID).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
              content: `بسبب الخمول لقد فاز ${st1usrrr} بمجموع \`${userr1r.result || 0}\`

    لقد خسر ${st2usrrr} بمجموع \`${userr2r.result || 0}\`

    > || ${st1usrrr} | ${st2usrrr} ||`, components: [], embeds: [embed]
            })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: st1usrrr.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: st1usrrr.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: st2usrrr.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr2st = await db.create({
                id: st2usrrr.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: d.id
            })
            await tkusr.findOneAndDelete({
              id: st1usrrr.id,
              msgID: d.msgID
            })
            await tkusr.findOneAndDelete({
              id: st2usrrr.id,
              msgID: d.msgID
            })
            await game.findOneAndDelete({
              id: d.id,
              with: d.with,
              msgID: d.msgID
            })
          }
          if (!ndata && !tkdata) {
            let stusrgame = client.users.cache.get(d.id)
            if (!stusrgame) stusrgame = "unknown";
            let wthusrgame = client.users.cache.get(d.with)
            if (!wthusrgame) wthusrgame = "unknown";
            let gdata = await game.findOne({
              id: d.id,
              with: d.with,
              msgID: d.msgID
            })
            client.channels.cache.get(gdata.channelID).messages.fetch(d.msgID).then(msg1 => msg1.edit({
              embeds: [], content: `تم إلغاء التحدي بسبب الخمول
    > || ${stusrgame} | ${wthusrgame} || `, components: []
            })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: d.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: d.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let datacoinsusr2st = await db.findOne({
              id: d.with
            })
            if (!datacoinsusr2st) {
              datacoinsusr2st = await db.create({
                id: d.with,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            if (gdata) {
              await game.findOneAndDelete({
                id: d.id,
                with: d.with,
                msgID: d.msgID
              })
            }
          }
        }
      })
    }, 8000)
  })



  client.probot.on("transfered", async (guild, data, err) => {
    if (err) return console.log(err);
    var { member, price, receiver, isOwner, fullPrice, channel } = data;
    if (isOwner == false) return;
    let datausr = await db.findOne({
      id: member.id
    })
    if (!datausr) {
      datausr = await db.create({
        id: member.id,
        coins: 0,
        status_playing: "no"
      })
    }

    let embed = new Discord.MessageEmbed()
      .setColor("GREYPLE")
    .setThumbnail(member.user.displayAvatarURL({dynamic: true}))
      .addFields({ name: 'المبلغ', value: `>  \`${price}\` ` }, { name: `الرصيد الحالي`, value: `>  \`${parseInt(datausr.coins) +  parseInt(price)}\` `  })
      .setFooter(channel.guild.name)
        .setTimestamp()
      member.send({ embeds: [embed], content:  ` > ${member} **تم الشحن بنجاح** ` })
      datausr.coins = parseInt(datausr.coins) + parseInt(price)
      await datausr.save()
      })




  /*
  client.on("messageCreate", async message => {
    if (message.content.includes("#credit") || message.content.includes("#credits") || message.content.includes("/credits") || message.content.includes("c") || message.content.includes("C")) {
      if (!message.content.includes(ownertr)) return;
      let credits = message.content.split(" ")[2]
      if (!credits) return;
      let coins = tax(credits)
      let coinss = credits - (coins.protax)
      let collect1 = await message.channel.awaitMessages({ filter: m => m.author.id == probotId, max: 1 }).catch(() => 0);
      if (!collect1.first().content.includes(`** ${message.author.username}, Transfer Fees: \`${coins.protax}\`, Amount :\`$${coinss}\``)) return;
      const filter = ({ content, author: { id } }) => {
        return content.startsWith(`**:moneybag: | ${message.author.username}, has transferred `) && content.includes(`${ownertr}`) && id === probotId && content.includes(`${coinss}`)
      }
    message.react('😄');
      let data = await db.findOne({
        id: message.author.id
      })
      if (!data) {
        data = await db.create({
          id: message.author.id,
          coins: 0,
          status_playing: "no"
        })
      }
      message.channel.awaitMessages({
        filter,
        max: 1,
        time: 13000,
        errors: ['time']
      }).then(async msg => {
        let embed = new Discord.MessageEmbed()
          .setColor("BLACk")
          .setThumbnail(message.guild.iconURL({ dynamic: true }))
          .setDescription("تم الشحن بنجاح")
          .addFields({ name: 'المبلغ', value: `> ${coinss}` }, { name: `المستلم`, value: `> ${message.author}` }, { name: `الرصيد الحالي`, value: `> ${parseInt(data.coins) + parseInt(coinss)}` })
          .setFooter(message.guild.name)
          .setTimestamp()
        message.channel.send({ embeds: [embed], content: `${message.author}` })
        data.coins = parseInt(data.coins) + parseInt(coinss)
        await data.save()
      })
    }
  })
  */



  // Auto Transfer Line
  client.probot = Probot(client, {
    data: [
      {
        guildId:  "1222868094888837141",
        probotId: "282859044593598464",
      },
    ],
  });

  client.probot.on("transfered", (guild, data, err) => {
    if (err) return console.log(err);
    if (guild.channel.id == "1251649131320180870") {
      guild.channel.send({ files: ["https://media.discordapp.net/attachments/1222938746941476996/1220441162964406364/20240316_233732.png?ex=660ef367&is=65fc7e67&hm=5a650c5ea5adf363fc4bb377ef763b7acb61ab7b38418ffae3e1e645c7a7895a&=&format=webp&quality=lossless"] });
    }
  });

// Code Dmuser
client.on('messageCreate', async (message) => {
  if(message.content.startsWith( "post")) {
    const user = message.mentions.members.first()
    let args = message.content.split(`${user}`).slice(1).join(" ");
    let args3 = message.content.split("").slice(1);
    let embed4 = new Discord.MessageEmbed()
    .setDescription("**Please Write A Message**")
    .setColor('BLUE')
      .setAuthor({name: message.author.tag,iconURL: 
       message.author.avatarURL({dynamic:true})})
    .setImage(line)
 if (!args || !args3) {
   return message.reply({embeds: [embed4]})
 }
    let embed = new Discord.MessageEmbed()
   .setTitle("Hatrex Casino")
   .setDescription(` **${args}**`)
  
    let embed2 = new Discord.MessageEmbed()
    .setDescription(`**Done <@${message.author.id}> To ${user}**`)
    .setColor('BLUE')
    .setAuthor({ name: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true}) })
    .setFooter({ text: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true}) })
    .setThumbnail(message.author.avatarURL())
    .setImage(line)

    let embed3 = new Discord.MessageEmbed()
    .setDescription("**The private is locked 🔒**")
    .setColor('BLUE')
    .setAuthor({ name: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true}) })
    .setFooter({ text: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true}) })
    .setThumbnail(message.author.avatarURL())
   .setImage(line)
const user2 = client.users.cache.get(`${user.id}`).send({embeds: [embed]}).then(async () => {
message.reply({embeds: [embed2]})}).catch(() => message.reply({embeds: [embed3]}))

  }
})

// Code User
client.on("messageCreate", message => {
    if(message.content.startsWith( "user")){
  let embed = new Discord.MessageEmbed()
  .setColor("RANDOM")
  .setAuthor({name: message.author.tag,iconURL: 
   message.author.avatarURL({dynamic:true})})
  .setThumbnail(message.author.avatarURL())
  .setFooter({ text: message.author.tag , iconURL: 
   message.author.displayAvatarURL({dynamic:true})})
  .setTitle("Info User")
  .addFields(
  {name: 'Name', value: `${message.author.tag}` , inline: false},
  {name: 'ID', value: `${message.author.id}` , inline: false},
  {name: 'Created At', value: `${message.author.createdAt.toLocaleString()}` , inline: false},
  )
  .setTimestamp(); 
  message.channel.send({ embeds: [embed] })
  }
  }); 

//  دخول بوت روم صوتي
const { joinVoiceChannel } = require('@discordjs/voice');

client.on('ready', () => {
  const channel = client.channels.cache.get('1251649131320180870');
  if (!channel) return console.error('The channel does not exist!');
  joinVoiceChannel({
    channelId: '1222868094888837145',
    guildId: '1222868094888837141',
    adapterCreator: channel.guild.voiceAdapterCreator,
  });
});


//ضريبة
let autotax = ['1222940879082356896'];

client.on("messageCreate", message => {
  if (message.channel.type === "dm" ||
    message.author.bot) return

  if (autotax.includes(message.channel.id)) {

    var args = message.content.split(' ').slice(0).join(' ')
    if (!args) return;

    if (args.endsWith("m")) args = args.replace(/m/gi, "") * 1000000;
    else if (args.endsWith("k")) args = args.replace(/k/gi, "") * 1000;
    else if (args.endsWith("K")) args = args.replace(/K/gi, "") * 1000;
    else if (args.endsWith("M")) args = args.replace(/M/gi, "") * 1000000;
      else if (args.endsWith("B")) args = args.replace(/M/gi, "") * 10000000;
        else if (args.endsWith("b")) args = args.replace(/M/gi, "") * 10000000;
    else if (args.endsWith("م")) args = args.replace(/M/gi, "") * 1000000;
    else if (args.endsWith("ك")) args = args.replace(/k/gi, "") * 1000;
    let args2 = parseInt(args)
    let tax = Math.floor(args2 * (20) / (19) + (1))
    let tax2 = Math.floor(args2 * (20) / (19) + (1) - (args2))
    let tax3 = Math.floor(tax2 * (20) / (19) + (1))
    let tax4 = Math.floor(tax2 + tax3 + args2);
    let tax5 = Math.floor((2.5 / 100) * args)
    let tax6 = Math.floor(tax4 + args2 * (20) / (19) + (1) - (args2))
    let tax7 = Math.floor(tax + tax5)
    let tax8 = Math.floor(tax4 + tax5)
    let tax9 = Math.floor((5 / 100) * args - args * -0)
    let tax10 = Math.floor(tax - args)
    let tax11 = Math.floor(tax9 + tax10)
    let tax12 = Math.floor(tax - tax11)


    let embed = new MessageEmbed()



      .setThumbnail(client.user.avatarURL({ dynamic: true }))
      .setTimestamp()

      .setFooter({
        text: `Rival Casino`, iconURL: `${message.author.displayAvatarURL()}`
      })

      .addFields(
        {

          name: "> **Your Tax**", value: `**\`\`\`${tax}\`\`\`**`
             })



      .setTimestamp()

    message.reply({ embeds: [embed] }).catch((err) => {
      console.log(err.message)
    });
  }
});



  // Auto Line
  client.on("message", message => {
    if (message.channel.id != "1251649131320180870") return;
    if(message.author.id === client.user.id) return;
        if (message.author.send) {
      message.channel.send({ files: ["https://cdn.discordapp.com/attachments/1222908078442151937/1222948861492989962/7-removebg-preview.png?ex=661812e1&is=66059de1&hm=5e9b9ddc44ba22e91f771bc97bdf0a559109b15e08e32a6e279e2bab65a5d4ef&"] });

    }
  })




//
client.on("messageCreate", message => {
  if (message.content ===  'Help' ||
      message.content.split(" ")[0] == "help" || message.content.split(" ")[0] == "اوامر") {
    let ping = new Discord.MessageEmbed()
      .setAuthor(message.author.tag, message.author.avatarURL({ dynamic: true }))
      .setDescription( `**امر \`تحدي\` قم عمل منشن لشخص و كتابه المبلغ ، مثل :
تحدي @m_ks2 5k

امر \`سحب\` هذا الأمر يجعلك تحويل كوينز الي كرديت ، مثل :
سحب 50k

امر \`فلوس\` هذا الأمر لترى رصيدك ورصيد الاخريين

امر \`ملف\`هذا الأمر لترى احصائيات لعبك واحصائيات غيرك

امر \`توب\` هذا الأمر لترى اغنياء الرصيد

امر \`تحويل\` هذا الأمر لتحويل رصيد من شخص إلى شخص أخر

امر \`تحدي عام/فرند\` هذا الأمر لتغير حالة التحدي مع لاعبين

امر \`فرند\`هذا الأمر لإضافة صديق

امر \`حذف\`فرند هذا الأمر لحذف صديق

امر \`فرندز\` هذا الأمر لرؤية اصدقائك

امر \`بلوك\` هذا الأمر لإعطاء احد اللاعبين بلوك

امر \`فك\` هذا الأمر لفك عن احد اللاعبين الذين يمتلكون بلوك

امر \`بلوكز\`هذا الأمر لرؤية اللاعبين الذين يمتلكون بلوك

**`)
      .setColor("GREYPLE");
    message.reply({ embeds: [ping] });
  }
});

client.on("messageCreate", message => {
  if (message.content ===  'ping') {
    let ping = new Discord.MessageEmbed()
      .setDescription(`**> 🔔 My Ping Is ${client.ws.ping}**`)
      .setColor("GREYPLE");
    message.reply({ embeds: [ping] });

      }
    });


client.on("messageCreate", async message => {
  if (message.content.split(" ")[0] == "بنك" || message.content.split(" ")[0] == "Bank" || message.content.split(" ")[0] == "bank" ||
message.content.split(" ")[0] == "بنك") {
    let embed = new Discord.MessageEmbed()
      .setColor("BLACK")
        .setThumbnail(message.author.avatarURL())
      .setAuthor(message.author.tag, message.author.avatarURL({ dynamic: true }))
      .setTitle(` **البنك الحالي لديك**`)
      .addFields({ name: `   رصيدك في البنك \`:\`   `, value: `
   $\`0\` ` }, )

    let button_info = new MessageButton()
    .setCustomId(`info_${message.author.id}`)
    .setLabel("سحب ")
    .setStyle("SUCCESS")

    let button_ichara = new MessageButton()
    .setCustomId('disabled')
    .setLabel("ايداع ")
    .setStyle("SECONDARY")
    .setDisabled(true);


  let row = new MessageActionRow()
      .setComponents(  button_info, button_ichara)
  message.reply({ embeds: [embed], components: [row], allowedMentions: { repliedUser: true } }).then(async msg => {


  })
  }
  })


client.on('clickButton', async (button) => {
    if (button.customId === "info") return;
    button.reply.send('ليس هناك اكواد للضغط عليها الرجاء المحاولة ف وقت اخر.', true)
    const member = button.clicker.member
})


// Code Say
client.on("messageCreate", async message => {
if (message.author.bot) return;
if (!message.channel.guild) return;
if (message.content.startsWith( 'say')) {
    if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("** 😕 You don't have permissions **"); 
}
if(!message.guild.me.permissions.has('ADMINISTRATOR')) {
  return message.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position. **`);
}
let args = message.content.split(' ').slice(2).join(' ')
let argss = message.content.split(' ')
        let channel = message.mentions.channels.first() || message.guild.channels.cache.get(argss[1])
        let attach = message.attachments.first()
        if (!channel) return message.channel.send('** 😕 Please mention channel or id **');
        if (!args) return message.channel.send('** ❌ Please select a message **');
        message.delete()
      if (!attach) {
        channel.send({content: `${args}`});
} else {
        channel.send({content: `${args}`, files: [attach]});
}
    }
})



//
client.on('messageCreate', message => {
    if (message.content === 'كاش' ||
       message.content.split(" ")[0] == "cashback") {
        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('select')
                    .setPlaceholder('قم بالاختيار فوراً')
                    .addOptions([
                      {
                        label:
 'سحب كل الكاش باك',
                        value:
 'الكاش باك'                         
                      },
                    ]),
            );

        message.channel.send({ content: '**> لسحب الكاش باك تبعك الرجاء اتباع الشروط التالية.**', components: [row] });
    }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isSelectMenu()) return;

  if (interaction.customId === 'select') {
    const user = await interaction.user.fetch();
    if(!user.dmChannel) {
      user.send(`**ليس لديك ${interaction.values[0]} للسحب \<1218225647445479477>** `);
      await interaction.deferReply({ ephemeral: true }); // تأجيل الرد على التفاعل السابق
      await interaction.editReply({ content: '**تم ارسال لك رسالة فالخاص بنجاح 🤑 **', ephemeral: true }); // إرسال رد جديد
    } else {
      await interaction.reply({ content: '**خاصيتك مغلقة، يرجى فتحها من إعدادات الخصوصية.**', ephemeral: true });
    }
  }
});

///auto react


client.on("message", async black => {
   ///replace 83838388 with id channel

  if (black.channel.id !="1217125264971006044") return;
  if(black.author.id === client.user.id) return;
      black.react("❤️")//react




  }

          )



client.on("messageCreate", async message => {
    if (message.author.bot) return;
  if (!message.guild) return;
  if (message.content.toLowerCase().startsWith( "tax","Tax","ضريبة".toLowerCase())) { 
  let args = message.content
    .split(" ")
    .slice(1)
    .join(" "); 
    if(!args) return message.reply("**:rolling_eyes: Please enter a number**").catch((err) => {
   console.log(err.message)
   });

if (args.endsWith("m")) args = args.replace(/m/gi, "") * 1000000;
else if (args.endsWith("k")) args = args.replace(/k/gi, "") * 1000;
  else if (args.endsWith("ك")) args = args.replace(/k/gi, "") * 000;
    else if (args.endsWith("م")) args = args.replace(/M/gi, "") * 000000;
else if (args.endsWith("K")) args = args.replace(/K/gi, "") * 1000;
else if (args.endsWith("M")) args = args.replace(/M/gi, "") * 1000000;
     let args2 = parseInt(args)
    let tax = Math.floor(args2 * (20) / (19) + (1))
    let tax2 = Math.floor(args2 * (20) / (19) + (1) - (args2))
    let tax3 = Math.floor(tax2 * (20) / (19) + (1))
    let tax4 = Math.floor(tax2 + tax3 + args2)

    let embed = new MessageEmbed()

.setAuthor(`Your Tax Now!`, client.user.avatarURL({ dynamic: true }))

   .setThumbnail(client.user.avatarURL({ dynamic: true }))   

.addFields([
    {
    name: `Tax : `,
    value: `\`\`\`${tax}\`\`\``
}
])
        .setColor(message.guild.me.displayColor)
  .setTimestamp()

   message.reply({embeds: [embed]}).catch((err) => {
   console.log(err.message)
   });    
  }
}); 


//sa7eb
client.on('channelCreate' , async(message) => {
  if(message.parentId != applycategory) return;
    setTimeout(() => {    
    message.send({ content: `> ** Click On The Button To Start Transaction Submition **
  > ** برجاء الضغط علي البتن لبدئ عملية السحب ** 

  ` , components: [
      new MessageActionRow()
      .addComponents(
        new MessageButton()
        .setLabel("قم بالسحب")
        .setStyle("SECONDARY")
        .setCustomId("hh")
      )
    ]})
       }, 2000);  
    client.on('interactionCreate' , async(interaction) => {
      if(interaction.customId == "hh") {
            const modal = new Modal()
        .setCustomId('myModal')
        .setTitle('Transaction Submit');
      const rname = new TextInputComponent()
        .setCustomId('rname')
        .setLabel("ما هو المبلغ الي تبي تسحبه")
        .setStyle('SHORT');



      const name = new MessageActionRow().addComponents(rname);

      // Add inputs to the modal
      modal.addComponents(name );
      // Show the modal to the user
      await interaction.showModal(modal);

          client.on('interactionCreate', async(interaction) => {
    if (!interaction.isModalSubmit()) return;

    if (interaction.customId === 'myModal') {

      const name = interaction.fields.getTextInputValue('rname');

  await interaction.reply({ content: `
  > *الرجاء انتضار الاونر*`,embeds: [
        new MessageEmbed()
          .setThumbnail(interaction.guild.iconURL({ dynamic: true }))

          .setAuthor({ name: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true}) })
          .setFooter({ text: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true}) })
          .setTimestamp()
        .setDescription(`
  \`\`\` New Transaction Team Submition \`\`\`

  > **__Transaction Price__** \`:\` \`${name}\` 


  `)
    .setImage(line)
      ] });
      interaction.channel.send("> || <@&1207063003321602069> ||")
       interaction.channel.send("> || ** https://discord.com/channels/1121046169817206805/1217125264971006044 لا تنسى التقييم     ***||")
    }
  });
      }
    })
    })

  client.on("messageCreate", async message => {
    if (message.content.split(" ")[0] == "friends" || message.content.split(" ")[0] == "Friends" || message.content.split(" ")[0] == "فرندز") {
        let args = message.content.split(" ")
         if (!args[2]) return message.reply({ content: `> **😔 ليس لديك أصدقاء**.` })
        if (user.bot) return message.reply({ content: `> **😔 ليس لديك أصدقاء**. ` })
        }
     })




client.on("messageCreate", async message => {
  if (message.content.split(" ")[0] == "sa7b" || message.content.split(" ")[0] == "Sa7b" || message.content.split(" ")[0] == "سحب") {
      let args = message.content.split(" ")
       if (!args[2]) return message.reply({ content: `**عذراً ياعزيزي ولاكن السحب يعمل فقط ف <#1251649131320180870> >**  ` })
      if (user.bot) return message.reply({ content: `**عذراً ياعزيزي ولاكن السحب يعمل فقط ف <#1251649131320180870> >**   ` })
      }
   })









  client.on("messageCreate", async message => {
    if (message.content.split(" ")[0] == "فلوس" || message.content.split(" ")[0] == "Money" || 
  message.content.split(" ")[0] == "رصيد" || message.content.split(" ")[0] == "money") {

      let user = message.mentions.users.first() || message.author
      let data = await db.findOne({
        id: user.id
      })
      if (!data) {
        data = await db.create({
          id: user.id,
          coins: 0,
          status_playing: "no"
        })
      }
      let embed = new Discord.MessageEmbed()
        .setColor("GREYPLE")
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .setTitle(`الرصيد الحالي لـ ${user.tag}`)
        .setDescription(`> **$**__${parseInt(data.coins).toLocaleString()}__`)
        .setFooter(message.guild.name)
        .setTimestamp()
      message.reply({ embeds: [embed] })
    }
  })



  client.on("messageCreate", async message => {
    if (message.content.split(" ")[0] == "تحويل" || message.content.split(" ")[0] == "Transfer" || message.content.split(" ")[0] == "transfer") {
      let data = await db.findOne({
        id: message.author.id
      })
      if (!data) {
        data = await db.create({
          id: message.author.id,
          coins: 0,
          status_playing: "no"
        })
      }
      if (data.status_playing == "yes") return message.reply({ content: `> لا يمكنك التحويل ل عضو اثناء تحدي !` })
      let args = message.content.split(" ")
      if (!args[1]) return message.reply({ content: `عذراً و لاكن يجب عليك منشن الشخص الذي تريد تحويل الكوينز اليه` })
      let user = message.mentions.users.first() || message.guild.members.cache.find(s => s.id == args[1])
      if (!user) return message.reply({ content: `\`❎\` **لم استطيع العثور على هذا الشخص**` })
      let data2 = await db.findOne({
        id: user.id
      })
      if (!data2) {
        data2 = await db.create({
          id: user.id,
          coins: 0,
          status_playing: "no"
        })
      }
      if (data2.status_playing == "yes") return message.reply({ content: `> لا يمكنك التحويل ل عضو اثناء تحدي !` })
      if (!args[2]) return message.reply({ content: `> لم تقم بتحديد المبلغ !` })
      let coinAmount = args[2];
          if (coinAmount.startsWith("0")) {
   if (coinAmount.startsWith("-")) {
        return message.reply("**لا يمكنك التحويل بالسالب**");
      }
            return message.reply("\`❎\` **برجاء وضع ارقام صحيحة**");
      }
      // Check if the mentioned user is the same as the command issuer
      if (user.id === message.author.id) {
        return message.reply("**لا يمكنك التحويل لنفسك**");
      }
      if (args[2].endsWith("k") || args[2].endsWith("K") || args[2].endsWith("m") || args[2].endsWith("M") || args[2].endsWith("ك") || args[2].endsWith("مليون") || 
 args[2].endsWith("م")) {
        if (args[2].includes(".") || args[2].includes(",")) return message.reply({ content: `\`❎\` **لا يمكن اضافة ارقام عشرية**` })
        let coin = args[2].replace("k", `000`).replace("m", `000000`).replace("K", `000`).replace("M", `000000`).replace("ك", `000`).replace("م", `000000`).replace("مليون", `000000`)
        if (parseInt(data.coins) == 0) return message.reply({ content: `\`❎\` **لا يمكنك التحويل ، ليس لديك الرصيد الكافي**` })
        if (parseInt(data.coins) < parseInt(coin)) return message.reply({ content: `\`❎\` **ليس لديك رصيد كافي لتحويل هذا المبلغ**` })
        let embed = new Discord.MessageEmbed()
          .setColor("BLACK")
          .setThumbnail(message.author.avatarURL({ dynamic: true }))
          .addFields({ name: 'المبلغ', value: `> \`${parseInt(coin)}\` ` }, { name: `المستلم`, value: `> ${user}` }, { name: `بواسطة`, value: `> ${message.author}` },    { name: `الرصيد الحالي`, value: `> \`${parseInt(data.coins) - parseInt(coin)}\` ` })
          .setFooter(message.guild.name)
          .setTimestamp()
        message.channel.send({ embeds: [embed], content: `> ${message.author}` })
           user.send({ content: `\<:visa:1195014613146816572> **| تم التحويل لك بنجاح**\n**You have received \`${parseInt(args[2])}\` from user  ${message.author}  \nReason:  || 'No reason provided' **` })
        data.coins = parseInt(data.coins) - parseInt(coin)
        await data.save()
        data2.coins = parseInt(data2.coins) + parseInt(coin)
        await data2.save()

      const td = await Data.findOne({ _id: message.author.id})
      if (td?.s) {
        await Data.findOneAndUpdate({ _id: message.author.id }, { s: td.s + parseInt(coin) }).then(() => {
        });
      } else if (!td?.s) {
        await Data.findOneAndUpdate({ _id: message.author.id }, { s: parseInt(coin) }).then(() => {
        });
      } else if (!td) {
        await Data.create({ _id: message.author.id, s: parseInt(coin)})
      }
      const tdd = await Data.findOne({ _id:user.id})
      if (tdd?.w) {
        await Data.findOneAndUpdate({ _id: user.id }, { w: tdd.w + parseInt(coin) }).then(() => {
        });
      } else if (!tdd?.w) {
        await Data.findOneAndUpdate({ _id: user.id }, { w: parseInt(coin) }).then(() => {
        });
      } else if (!tdd) {
        await Data.create({ _id: user.id, w: parseInt(coin)})
      }
        return;
      }
      if (isNaN(args[2])) return message.reply({ content: `\`❎\` **برجاء وضع ارقام صحيحة**` })
      if (args[2].includes(".") || args[2].includes(",")) return message.reply({ content: `\`❎\` **لا يمكن تحويل ارقام عشرية**` })
      if (parseInt(data.coins) == 0) return message.reply({ content: ` عذراً و لاكن ليس لديك فلوس للتحويل` })
      if (parseInt(data.coins) < parseInt(args[2])) return message.reply({ content: `\`❎\` **ليس لديك فلوس كافية لتحويل هذا المبلغ**` })
      let embed = new Discord.MessageEmbed()
        .setColor("BLUE")
        .setThumbnail(message.author.avatarURL({ dynamic: true }))
        .addFields({ name: 'المبلغ', value: `> \`${parseInt(args[2])}\` ` }, { name: `المستلم`, value: `> ${user}` }, { name: `بواسطة`, value: `> ${message.author}` },   { name: `الرصيد الحالي`, value: `> \`${parseInt(data.coins) - parseInt(args[2])}\` ` })
        .setFooter(message.guild.name)
        .setTimestamp()
      message.channel.send({ embeds: [embed], content: ` > ${message.author}` })
              user.send({ content: `\<:visa:1195014613146816572> **| تم التحويل لك بنجاح**\n**You have received \`${parseInt(args[2])}\` from user  ${message.author}  \nReason:  || 'No reason provided' **` })
      data.coins = parseInt(data.coins) - parseInt(args[2])
      await data.save()
      data2.coins = parseInt(data2.coins) + parseInt(args[2])
      await data2.save()

      const td = await Data.findOne({ _id: message.author.id})
      if (td?.s) {
        await Data.findOneAndUpdate({ _id: message.author.id }, { s: td.s +  parseInt(args[2]) }).then(() => {
        });
      } else if (!td?.s) {
        await Data.findOneAndUpdate({ _id: message.author.id }, { s:  parseInt(args[2]) }).then(() => {
        });
      } else if (!td) {
        await Data.findOne({ _id: message.author.id, s:  parseInt(args[2])})
      }
      const tdd = await Data.findOne({ _id:user.id})
      if (tdd?.w) {
        await Data.findOneAndUpdate({ _id: user.id }, { w: tdd.w +  parseInt(args[2]) }).then(() => {
        });
      } else if (!tdd?.w) {
        await Data.findOneAndUpdate({ _id: user.id }, { w:  parseInt(args[2]) }).then(() => {
        });
      } else if (!tdd) {

        await Data.create({ _id: user.id, w:  parseInt(args[2])})
      }
    }
    })


// Code Lock
client.on('messageCreate', message => {
  if(message.content.startsWith( 'lock')) {
     message.delete();
    if(!message.member.permissions.has('MANAGE_CHANNELS'))return;
    let oqdl = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setCustomId('lock-oqdl')
      .setLabel('lock')
      .setStyle('PRIMARY')
      .setEmoji('🔒'),
      new MessageButton()
      .setCustomId('unlock-oqdl')
      .setLabel('unlock')
      .setStyle('SUCCESS')
      .setEmoji('🔓'),
    )
    message.channel.send({content: '> **اختارعايز تقفل الروم او تفتح الروم**', components: [oqdl]})
    const collector = message.channel.createMessageComponentCollector({componentType: 'BUTTON', max: 1,time: ms('10s')})

    collector.on('collect', oqdl => {
      if(!oqdl.member.permissions.has('MANAGE_CHANNELS'))return;
      if(oqdl.customId === 'lock-oqdl'){
        oqdl.channel.permissionOverwrites.edit(
          oqdl.guild.roles.everyone, {
            SEND_MESSAGES: false,
          }
        )
        oqdl.update({content: `🔒 ${oqdl.channel} **has been locked.**`, components:[]})
      }
      if(oqdl.customId === 'unlock-oqdl'){
        oqdl.channel.permissionOverwrites.edit(
          oqdl.guild.roles.everyone, {
            SEND_MESSAGES: true,
          }
        )
        oqdl.update({content: `🔓 ${oqdl.channel} **has been unlocked.**`, components:[]})
      }
    })
  }
})




client.on('messageCreate', async(message) => {
  if(message.author.bot) return;
  if(message.content === "تحدي عام") {
    message.reply(`
 \`✅\` **تم تغير حالتك بنجاح إلى __العام__ .** `)
  }
  if(message.content === "تحدي فرند") {
message.channel.send(` \`✅\` **تم تغير حالتك بنجاح إلى __الأصدقاء __ .**
`)
  }
   })



  client.on("messageCreate", async message => {
    if(message.content.split(" ")[0] == "add" || message.content.split(" ")[0] == "Add" || message.content.split(" ")[0] == "خذ" || message.content.split(" ")[0] == "اضافة"){
      if (!owners.find(s => s == message.author.id)) return;
      let args = message.content.split(" ")
      if (!args[1]) return message.reply({ content: `> لم تقم بتحديد العضو !` })
      let user = message.mentions.users.first() || message.guild.members.cache.find(s => s.id == args[1])
      if (!user) return message.reply({ content: `\`❎\` **لم استطيع العثور على هذا الشخص**` })
      if (!args[2]) return message.reply({ content: `> لم تقم بتحديد المبلغ !` })
      if (args[2].endsWith("k") || args[2].endsWith("K") || args[2].endsWith("m") || args[2].endsWith("M") || args[2].endsWith("ك") || args[2].endsWith("م")) {
        if (args[2].includes(".") || args[2].includes(",")) return message.reply({ content: `\`❎\` **لا يمكن اضافة ارقام عشرية**` })
        let coin = args[2].replace("k", `000`).replace("m", `000000`).replace("K", `000`).replace("M", `000000`).replace("ك", `000`).replace("م", `000000`)
        let data = await db.findOne({
          id: user.id
        })
        if (!data) {
          data = await db.create({
            id: user.id,
            coins: 0,
            status_playing: "no"
           })
            }
        let embed = new Discord.MessageEmbed()
          .setColor("BLACK")
          .setThumbnail(user.avatarURL({ dynamic: true }))
          .setDescription(`تم الإضافة بنجاح`)
          .addFields({ name: "بواسطة", value: `${message.author}` }, { name: `اضاف`, value: `$${coin}` }, { name: `المستلم`, value: `${user}` }, { name: `الرصيد الحالي للمستلم`, value: `${parseInt(data.coins) + parseInt(coin)}` })
        message.reply({ embeds: [embed] })
        data.coins = parseInt(data.coins) + parseInt(coin)
        await data.save()
        return;
      }
      if (isNaN(args[2])) return message.reply({ content: `\`❎\` **برجاء وضع ارقام صحيحة**` })
      if (args[2].includes(".") || args[2].includes(",")) return message.reply({ content: `\`❎\` **لا يمكن اضافة ارقام عشرية**` })
      let data = await db.findOne({
        id: user.id
      })
      if (!data) {
        data = await db.create({
          id: user.id,
          coins: 0,
          status_playing: "no"
        })
      }
      let embed = new Discord.MessageEmbed()
        .setColor("BLACK")
        .setThumbnail(user.avatarURL({ dynamic: true }))
        .setDescription(`تم الإضافة بنجاح`)
        .addFields({ name: "بواسطة", value: `${message.author}` }, { name: `اضاف`, value: `$${args[2]}` }, { name: `المستلم`, value: `${user}` }, { name: `الرصيد الحالي للمستلم`, value: `${parseInt(data.coins) + parseInt(args[2])}` })
      message.reply({ embeds: [embed] })
      data.coins = parseInt(data.coins) + parseInt(args[2])
      await data.save()
    }
  })




client.on("messageCreate", async message => {
  if (message.content.split(" ")[0] == "rmv" || message.content.split(" ")[0] == "remove" || message.content.split(" ")[0] == "Remove" || message.content.split(" ")[0] == "Rmv") {
    if (!owners.find(s => s == message.author.id)) return;
    let args = message.content.split(" ")
    if (!args[1]) return message.reply({ content: `> لم تقم بتحديد العضو !` })
    let user = message.mentions.users.first() || message.guild.members.cache.find(s => s.id == args[1])
    if (!user) return message.reply({ content: `\`❎\` **لم استطيع العثور على هذا الشخص**` })
    if (!args[2]) return message.reply({ content: `> لم تقم بتحديد المبلغ !` })
    if (args[2].endsWith("k") || args[2].endsWith("K") || args[2].endsWith("m") || args[2].endsWith("M")) {
      if (args[2].includes(".") || args[2].includes(",")) return message.reply({ content: `\`❎\` **لا يمكن حذف ارقام عشرية**` })
      let coin = args[2].replace("k", `000`).replace("m", `000000`).replace("K", `000`).replace("M", `000000`)
      let data = await db.findOne({
        id: user.id
      })
      if (!data) {
        data = await db.create({
          id: user.id,
          coins: 0,
          status_playing: "no"
        })
      }
      if (data.coins == 0) return message.reply({ content: `\`❎\` **هذا الشخص ليس لديه اي رصيد للحذف**` })
      if (parseInt(data.coins) < parseInt(coin)) return message.reply({ content: `\`❎\` **هذا الشخص ليس معه هذا المبلغ لحذفه**` })
      let embed = new Discord.MessageEmbed()
        .setColor("GREEN")
        .setThumbnail(user.avatarURL({ dynamic: true }))
        .setDescription(`تم حذف بنجاح`)
        .addFields({ name: "بواسطة", value: `${message.author}` }, { name: `حذف`, value: `$${coin}` }, { name: `من`, value: `${user}` }, { name: `الرصيد الحالي للمستلم`, value: `${parseInt(data.coins) - parseInt(coin)}` })
      message.reply({ embeds: [embed] })
      data.coins = parseInt(data.coins) - parseInt(coin)
      await data.save()
      return;
    }
    if (isNaN(args[2])) return message.reply({ content: `\`❎\` **برجاء وضع ارقام صحيحة**` })
    if (args[2].includes(".") || args[2].includes(",")) return message.reply({ content: `\`❎\` **لا يمكن حذف ارقام عشرية**` })
    let data = await db.findOne({
      id: user.id
    })
    if (!data) {
      data = await db.create({
        id: user.id,
        coins: 0,
        status_playing: "no"
      })
    }
    if (data.coins == 0) return message.reply({ content: `\`❎\` **هذا الشخص ليس لديه اي رصيد للحذف**` })
    if (parseInt(data.coins) < parseInt(args[2])) return message.reply({ content: `\`❎\` **هذا الشخص ليس معه هذا المبلغ لحذفه**` })
    let embed = new Discord.MessageEmbed()
      .setColor("GREEN")
      .setThumbnail(user.avatarURL({ dynamic: true }))
      .setDescription(`تم حذف بنجاح`)
      .addFields({ name: "بواسطة", value: `${message.author}` }, { name: `حذف`, value: `$${args[2]}` }, { name: `من`, value: `${user}` }, { name: `الرصيد الحالي للمستلم`, value: `${parseInt(data.coins) - parseInt(args[2])}` })
    message.reply({ embeds: [embed] })
    data.coins = parseInt(data.coins) - parseInt(args[2])
    await data.save()
  }
})





  client.on("messageCreate", async message => {
    if (message.content.split(" ")[0] == "توب" || message.content.split(" ")[0] == "top" || message.content.split(" ")[0] == "Top") {
      let money = (await db.find()).sort((a, b) => b.coins - a.coins)
      var finalLb = "\<:Owner_ship:1223931908719640579>";
      let total = 0;
      let num = 0;
      for (var i in money) {
        if (message.guild.members.cache.get(money[i].id)) {
          total += parseInt(money[i].coins)
          num += 1;
          finalLb += `#${num}${client.users.cache.get(money[i].id)} **\`-\`** **${parseInt(money[i].coins).toLocaleString()}**\n`;
        }
        if (num == 10) {
          let total1 = total.toString()

          if (parseInt(total1.length) === 4) {
            if (total1.slice(1, 2) == 0) {
              total1 = `${total1.slice(0, 1)}K`;
            } else {
              total1 = `${total1.slice(0, 1)}.${total1.slice(1, 2)}K`;
            }
          }

          if (parseInt(total1.length) === 5) {
            if (total1.slice(2, 3)) {
              total1 = `${total1.slice(0, 2)}K`;
            } else {
              total1 = `${total1.slice(0, 2)}.${total1.slice(2, 3)}K`;
            }
          }

          if (parseInt(total1.length) === 6) {
            if (total1.slice(3, 4) == 0) {
              total1 = `${total1.slice(0, 3)}K`;
            }
            total1 = `${total1.slice(0, 3)}.${total1.slice(3, 4)}K`;
          }

          if (parseInt(total1.length) === 7) {
            if (total1.slice(1, 2) == 0) {
              total1 = `${total1.slice(0, 1)}M`;
            } else {
              total1 = `${total1.slice(0, 1)}.${total1.slice(1, 2)}M`;
            }
          }

          if (parseInt(total1.length) === 8) {
            if (total1.slice(2, 3) == 0) {
              total1 = `${total1.slice(0, 2)}M`;
            } else {
              total1 = `${total1.slice(0, 2)}.${total1.slice(2, 3)}M`;
            }
          }

          if (parseInt(total1.length) === 9) {
            if (total1.slice(3, 4) == 0) {
              total1 = `${total1.slice(0, 3)}M`;
            } else {
              total1 = `${total1.slice(0, 3)}.${total1.slice(3, 4)}M`;
            }
          }

          if (parseInt(total1.length) === 10) {
            if (total1.slice(1, 2) == 0) {
              total1 = `${total1.slice(0, 1)}B`;
            } else {
              total1 = `${total1.slice(0, 1)}.${total1.slice(1, 2)}B`;
            }
          }

          if (total.length === 11) {
            if (total1.slice(2, 3) == 0) {
              total1 = `${total1.slice(0, 2)}B`;
            } else {
              total1 = `${total1.slice(0, 2)}.${total1.slice(2, 3)}B`;
            }
          }

          if (parseInt(total1.length) === 12) {
            if (total1.slice(3, 4) == 0) {
              total1 = `${total1.slice(0, 3)}B`;
            } else {
              total1 = `${total1.slice(0, 3)}.${total1.slice(3, 4)}B`;
            }
          }
          const embed = new Discord.MessageEmbed()
            .setAuthor(`توب رصيد`)
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setColor("GOLD")
            .setDescription(finalLb)
            .setFooter(message.guild.name + " • " + total1)
            .setTimestamp()
          message.reply({ embeds: [embed] })
          return;
        }
      }
      let total1 = total.toString()

      if (parseInt(total1.length) === 4) {
        if (total1.slice(1, 2) == 0) {
          total1 = `${total1.slice(0, 1)}K`;
        } else {
          total1 = `${total1.slice(0, 1)}.${total1.slice(1, 2)}K`;
        }
      }

      if (parseInt(total1.length) === 5) {
        if (total1.slice(2, 3)) {
          total1 = `${total1.slice(0, 2)}K`;
        } else {
          total1 = `${total1.slice(0, 2)}.${total1.slice(2, 3)}K`;
        }
      }

      if (parseInt(total1.length) === 6) {
        if (total1.slice(3, 4) == 0) {
          total1 = `${total1.slice(0, 3)}K`;
        }
        total1 = `${total1.slice(0, 3)}.${total1.slice(3, 4)}K`;
      }

      if (parseInt(total1.length) === 7) {
        if (total1.slice(1, 2) == 0) {
          total1 = `${total1.slice(0, 1)}M`;
        } else {
          total1 = `${total1.slice(0, 1)}.${total1.slice(1, 2)}M`;
        }
      }

      if (parseInt(total1.length) === 8) {
        if (total1.slice(2, 3) == 0) {
          total1 = `${total1.slice(0, 2)}M`;
        } else {
          total1 = `${total1.slice(0, 2)}.${total1.slice(2, 3)}M`;
        }
      }

      if (parseInt(total1.length) === 9) {
        if (total1.slice(3, 4) == 0) {
          total1 = `${total1.slice(0, 3)}M`;
        } else {
          total1 = `${total1.slice(0, 3)}.${total1.slice(3, 4)}M`;
        }
      }

      if (parseInt(total1.length) === 10) {
        if (total1.slice(1, 2) == 0) {
          total1 = `${total1.slice(0, 1)}B`;
        } else {
          total1 = `${total1.slice(0, 1)}.${total1.slice(1, 2)}B`;
        }
      }

      if (total.length === 11) {
        if (total1.slice(2, 3) == 0) {
          total1 = `${total1.slice(0, 2)}B`;
        } else {
          total1 = `${total1.slice(0, 2)}.${total1.slice(2, 3)}B`;
        }
      }

      if (parseInt(total1.length) === 12) {
        if (total1.slice(3, 4) == 0) {
          total1 = `${total1.slice(0, 3)}B`;
        } else {
          total1 = `${total1.slice(0, 3)}.${total1.slice(3, 4)}B`;
        }
      }







      const embed = new Discord.MessageEmbed()
        .setAuthor(`توب رصيد`)
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .setColor("GOLD")
        .setDescription(finalLb)
        .setFooter(message.guild.name + " • " + total1)
        .setTimestamp()
      message.reply({ embeds: [embed] })
    }
  })

const guildId = '1222868094888837141';
const channelId = '1251649131320180870';

client.on('messageCreate', async (message) => {
    if (message.content.startsWith('سحبب')) {
        const amount = parseInt(message.content.split(' ')[2]);
        const user = message.mentions.users.first();

    if (!amount || !user) {
            return message.reply('عذراً ولكن يبدو أنك لم تقم بتحديد مبلغ للسحب .');
        }


        const guild = client.guilds.cache.get(guildId);
        const channel = guild.channels.cache.get(channelId);
        const member = guild.members.cache.get(user.id);

        if (!guild || !channel || !member) {
            return message.reply('لا يمكن العثور على الخادم أو القناة أو العضو.');
        }

        // سحب المال من العضو هنا

        const designatedChannel = guild.channels.cache.get(designatedChannelId);
        designatedChannel.send(`لقد سحب ${user} مبلغ ${amount} بنجاح.`);

        const row = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('confirmButton')
                    .setLabel('تم')
                    .setStyle('SUCCESS')
            );

        const confirmationMessage = await message.channel.send({
            content: `تم سحب ${amount} من ${user} وإرساله إلى الروم المخصص.`,
            components: [row]
        });

        const filter = (interaction) => {
            return interaction.customId === 'confirmButton' && interaction.user.id === message.author.id;
        };

        const collector = confirmationMessage.createMessageComponentCollector({ filter, time: 15000 });

        collector.on('collect', async (interaction) => {
            const userDM = await user.createDM();
            userDM.send('تم تسليمك المبلغ بنجاح.');
            collector.stop();
        });
    }
});



//
client.on('messageCreate', message => {
    if (message.content === 'بري' ||
       message.content.split(" ")[0] == "pre") {
                let ping = new Discord.MessageEmbed()
      .setDescription( ` > ** برجاء اختيار طريقة الدفع للإستمرار **`)
       .setColor("BLUE");
        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('select')
                    .setPlaceholder('اضغط هنا لاختيار عملية الشراء')
                    .addOptions([
                        {
                            label: 'hatrex Coins',
                            value: 'hatrex Coins',
                          emoji: {
                              id: '1223931744814628947',
                              name: ':dakicoin:'
                          }

                        },

                      {
                        label:
 ' Probot Credits ',
                        value:
 'Probot Credits '                

                      },
                    ]),
            );

        message.channel.send({ content: '**> الرجاء اختيار طرق الدفع \<:vip:1223931706822754396> **', components: [row] });
    }
});





client.on("messageCreate", async message => {
  if(message.content.split(" ")[0] == "challenge" || 
     message.content.split(" ")[0] == "Challenge"){

    let data = await db.findOne({
      id: message.author.id
    })
    if (!data) {
      data = await db.create({
        id: message.author.id,
        coins: 0,
        status_playing: "no"
      })
    }
   if (data.status_playing == "yes") return message.reply({ content: `\`❎\` **لا يمكنك اللعب ، لأنك تمتلك تحدي جاري**` })
    let args = message.content.split(" ")
    if (!args[1]) return message.reply({ content: `عذراً و لاكن يبدو انك لم تقم بتحديد اللاعب` })
    let user = message.mentions.users.first() || message.guild.members.cache.find(s => s.id == args[1])
    if (!user) return message.reply({ content: `\`❎\` **لم استطيع العثور على هذا الشخص**` })
    let first = message.content.slice(32)
     let coinAmount = first.replace("k",`000`).replace("m",`000000`).replace("K",`000`).replace("M",`000000`).replace("ك",`000`).replace("م",`000000`).replace("مليون",`000000`)
     first.replace("k",`٠٠٠`).replace("m",`٠٠٠٠٠٠`).replace("K",`٠٠٠`).replace("M",`٠٠٠٠٠٠`).replace("ك",`٠٠٠`).replace("م",`٠٠٠٠٠٠`).replace("مليون",`٠٠٠٠٠٠`)
if (!coinAmount) return message.reply({ content: `عذراً و لاكن يبدو انك لم تقم بتحديد المبلغ` });



    let alpha = first.slice(first.length - 1)

    if (coinAmount < 0) {
      return message.reply("عذراً و لاكن لا تستطيع التحدي بالسالب");
    }

if (isNaN(coinAmount) || coinAmount <= 0) {
      return message.reply("عذراً و لاكن هذا الرقم ليس صحيح");
    }






    if (user.id == message.author.id) return message.reply({ content: `\`❎\` **لا يمكنك اللعب ضد نفسك**` })
    if (!args[2]) return message.reply({ content: `عذراً و لاكن يبدو انك لم تقم بتحديد العضو للعب` })

    let data2 = await db.findOne({
      id: user.id
    })
    if (!data2) {
      data2 = await db.create({
        id: user.id,
        coins: 0,
        status_playing: "no"
      })
    }
    if (data2.status_playing == "yes") return message.reply({ content: `> العضو يمتلك تحدي جاري حاليا !` })
    if ((parseInt(data.coins) < coinAmount) && ((parseInt(data2.coins) < coinAmount))) return message.reply({ content: `\`❎\` **ليس لديك ما يكفي انت وصديقك للتحدي على ${coinAmount}**` })
    if (parseInt(data.coins) < coinAmount) return message.reply({ content: `\`❎\` **ليس لديك ما يكفي للتحدي على ${coinAmount}**` })
    if (parseInt(data2.coins) < coinAmount) return message.reply({ content: `\`❎\` **ليس لدى صديقك ما يكفي للتحدي على ${coinAmount}**` })
    let embed = new Discord.MessageEmbed()
          .setColor("GREY")
          .setAuthor(message.author.tag, message.author.avatarURL({ dynamic: true }))
          .setTitle("اختار نوع اللعبة")
          .setDescription(`> العضو: ${user}\n
    المبلغ: \`${coinAmount}\``)
      .addFields({ name: `- لـعبة الـ زهر  🎲 :`, value: `*لديك ثلاث محاولات للحصول عـلي أعلي رقم و الفوز ، التعآدل ليس فوزاً .!*` }, { name: `- لـعبة الـ تقريبي 📊 :`, value: `> *سيظهر لك ارقام عشوائيه و يجب عليك اختيار بين اقل نتيجه او اكبر نتيجه , للحصول علي الحد الاقصي او اقرب رقم له , قد يكون الحظ حليفك او لا . التعادل ليس فوزا .!*` } ,{ name: `- لعبة البحث عن الزر 🧠 `, value: `*قم باختيار الزر الصحيح للفوز.!*` })


        let button_nrd = new MessageButton()
          .setCustomId(`nrd_${message.author.id}`)
          .setLabel("النرد")
          .setEmoji("🎲")
          .setStyle("SECONDARY")

        let button_rkmtakribi = new MessageButton()
          .setCustomId(`takribi_${message.author.id}`)
          .setLabel("الرقم التقريبي")
          .setEmoji("📊")
          .setStyle("SECONDARY")



      let button_xo = new MessageButton()
      .setCustomId(`xo_${message.author.id}`)
      .setLabel(" X O")
      .setEmoji("❌")
      .setStyle("SECONDARY")



              let button_tartib = new MessageButton()
          .setCustomId(`tartib_${message.author.id}`)
          .setLabel("البحث عن الزر")
          .setEmoji("🧠")
          .setStyle("SECONDARY")
            .setDisabled(true);




        let button_cancel = new MessageButton()
          .setCustomId(`cancel_${message.author.id}`)
          .setLabel("إلغاء")
          .setStyle("DANGER")




        let row = new MessageActionRow()
          .setComponents(button_nrd, button_rkmtakribi, button_tartib, button_xo,   button_cancel)


      message.reply({ embeds: [embed], components: [row], allowedMentions: { repliedUser: true } }).then(async msg => {
        let gdata = await game.findOne({
          id: message.author.id
        })
        if (!gdata) {
          gdata = await game.create({
            id: message.author.id,
            msgID: msg.id,
            coins: coinAmount,
            with: user.id,
            game: null,
            channelID: message.channel.id,
            time: timestamp(moment(ms("40s")) + Date.now()),
          })
        } else {
          gdata = await game.findOneAndUpdate({
            id: message.author.id,
            msgID: msg.id,
            coins: coinAmount,
            with: user.id,
            game: null,
            channelID: message.channel.id,
            time: timestamp(moment(ms("40s")) + Date.now()),
          })
        }
        data2.status_playing = "yes";
        await data2.save()
        data.status_playing = "yes";
        await data.save()
      })
    }
    if (message.content.split(" ")[0] == "تحدي") {
      let data = await db.findOne({
        id: message.author.id
      })
      if (!data) {
        data = await db.create({
          id: message.author.id,
          coins: 0,
          status_playing: "no"
        })
      }
    if (data.status_playing == "yes") return message.reply({ content: `\`❎\` **لا يمكنك اللعب ، لأنك تمتلك تحدي جاري**` })
      let args = message.content.split(" ")
      if (!args[1]) return message.reply({ content: `عذراً و لاكن يبدو انك لم تقم بتحديد اللاعب` })
      let user = message.mentions.users.first() || message.guild.members.cache.find(s => s.id == args[1])
      if (!user) return message.reply({ content: `\`❎\` **لم استطيع العثور على هذا الشخص**` })
      let first = message.content.slice(27)
       let coinAmount = first.replace("k",`000`).replace("m",`000000`).replace("K",`000`).replace("M",`000000`).replace("ك",`000`).replace("م",`000000`).replace("مليون",`000000`)
      if (!coinAmount) return message.reply({ content: `عذراً و لاكن يبدو انك لم تقم بتحديد المبلغ` });



      let alpha = first.slice(first.length - 1)

      if (coinAmount < 0) {
        return message.reply("عذراً و لاكن لا يمكنك التحدي بالسالب");
      }



  if (isNaN(coinAmount) || coinAmount <= 0) {
    return message.reply("`❎` **برجاء وضع ارقام صحيحة**");
  }




      if (user.bot) return message.reply({ content: `\`❎\` اللعب ضد البوت هيكون ف اقرب وقت عشان ميزة جديد بتكون له` })
      if (user.id == message.author.id) return message.reply({ content: `\`❎\` **لا يمكنك اللعب ضد نفسك**` })
      if (!args[2]) return message.reply({ content: `عذراً و لاكن يبدو انك لم تقم بتحديد المبلغ` })

      let data2 = await db.findOne({
        id: user.id
      })
      if (!data2) {
        data2 = await db.create({
          id: user.id,
          coins: 0,
          status_playing: "no"
        })
      }
      if (data2.status_playing == "yes") return message.reply({ content: `> العضو يمتلك تحدي جاري حاليا !` })
      if ((parseInt(data.coins) < coinAmount) && ((parseInt(data2.coins) < coinAmount))) return message.reply({ content: `\`❎\` **ليس لديك ما يكفي انت وصديقك للتحدي على ${coinAmount}**` })
      if (parseInt(data.coins) < coinAmount) return message.reply({ content: `\`❎\` **ليس لديك ما يكفي للتحدي على ${coinAmount}**` })
      if (parseInt(data2.coins) < coinAmount) return message.reply({ content: `\`❎\` **ليس لدى صديقك ما يكفي للتحدي على ${coinAmount}**` })
      let embed = new Discord.MessageEmbed()
        .setColor("GREY")
        .setAuthor(message.author.tag, message.author.avatarURL({ dynamic: true }))
        .setTitle("اختار نوع اللعبة")
        .setDescription(`> العضو: ${user}\n
  المبلغ: \`${coinAmount}\``)
          .addFields({ name: `- لـعبة الـ زهر  🎲 :`, value: `*لديك ثلاث محاولات للحصول عـلي أعلي رقم و الفوز ، التعآدل ليس فوزاً .!*` }, { name: `- لـعبة الـ تقريبي 📊 :`, value: `> *سيظهر لك ارقام عشوائيه و يجب عليك اختيار بين اقل نتيجه او اكبر نتيجه , للحصول علي الحد الاقصي او اقرب رقم له , قد يكون الحظ حليفك او لا . التعادل ليس فوزا .!*` } ,{ name: `- لعبة البحث عن الزر 🧠 `, value: `*قم باختيار الزر الصحيح للفوز.!*` })


          let button_nrd = new MessageButton()
            .setCustomId(`nrd_${message.author.id}`)
            .setLabel("النرد")
            .setEmoji("🎲")
            .setStyle("SECONDARY")

          let button_rkmtakribi = new MessageButton()
            .setCustomId(`takribi_${message.author.id}`)
            .setLabel("الرقم التقريبي")
            .setEmoji("📊")
            .setStyle("SECONDARY")



        let button_xo = new MessageButton()
        .setCustomId(`xo_${message.author.id}`)
        .setLabel(" X O")
        .setEmoji("❌")
        .setStyle("SECONDARY")



                let button_tartib = new MessageButton()
            .setCustomId(`tartib_${message.author.id}`)
            .setLabel("البحث عن الزر")
            .setEmoji("🧠")
            .setStyle("SECONDARY")
              .setDisabled(true);




          let button_cancel = new MessageButton()
            .setCustomId(`cancel_${message.author.id}`)
            .setLabel("إلغاء")
            .setStyle("DANGER")




          let row = new MessageActionRow()
            .setComponents(button_nrd, button_rkmtakribi, button_tartib, button_xo,   button_cancel)

      message.reply({ embeds: [embed], components: [row], allowedMentions: { repliedUser: false } }).then(async msg => {
        let gdata = await game.findOne({
          id: message.author.id
        })
        if (!gdata) {
          gdata = await game.create({
            id: message.author.id,
            msgID: msg.id,
            coins: coinAmount,
            with: user.id,
            game: null,
            channelID: message.channel.id,
            time: timestamp(moment(ms("40s")) + Date.now()),
          })
        } else {
          gdata = await game.findOneAndUpdate({
            id: message.author.id,
            msgID: msg.id,
            coins: coinAmount,
            with: user.id,
            game: null,
            channelID: message.channel.id,
            time: timestamp(moment(ms("40s")) + Date.now()),
          })
        }
        data2.status_playing = "yes";
        await data2.save()
        data.status_playing = "yes";
        await data.save()
      })
    }
  })




client.on('interactionCreate', async interaction => {
  if (interaction.isButton()) {
    //nrd game

    if (interaction.customId == `nrd_${interaction.user.id}`) {
      let gdata = await game.findOne({
        id: interaction.user.id
      })

      if (!gdata) return;
      if (!gdata.coins || gdata.coins == null) return;
      if (!gdata.with || gdata.with == null) return;
      if (!gdata.msgID || gdata.msgID == null) return;
      gdata.game = "nrd"
      await gdata.save()
      gdata.time = timestamp(moment(ms("40s")) + Date.now())
      await gdata.save()


      await interaction.deferReply({ ephemeral: true })
      let embed_edit = new Discord.MessageEmbed()
        .setColor("BLACK")
        .setDescription(`> *تنبيه: في حال عدم استجابة الطرفين و عدم اكمال التحدي يؤدي الى خصم نصف المبلغ من الطرفين.
> عند التعادل لا يتم سحب اي مبلغ من الطرفين.*`)
        .addFields({ name: `- لـعبة الـ زهر  🎲 :  `, value: `*لعبة النرد أو ، والتعادل ليس فوزاً .!*` }, { name: `المبلغ:`, value: `${parseInt(gdata.coins)}` })


      let button_yes = new MessageButton()
        .setCustomId(`yesg_${gdata.msgID}`)
        .setLabel("قبول")
        .setStyle("SUCCESS")

      let button_no = new MessageButton()
        .setCustomId(`nog_${gdata.msgID}`)
        .setLabel("رفض")
        .setStyle("DANGER")

      let row = new MessageActionRow()
        .setComponents(button_yes, button_no)

      interaction.editReply({ content: `> لقد تم اختيار العبة هي : \`نرد\` !!`, ephemeral: true })
      client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit], components: [row] })).catch(err => console.error(err))
    }

    if (interaction.customId == `yesg_${interaction.message.id}`) {
      let gdatawith = await game.findOne({
        with: interaction.user.id
      })
      const dd = await Data.findOne({ _id: interaction.user.id })
      if (dd) {
          await Data.findOneAndUpdate({ _id: interaction.user.id }, { t: dd.t+1}).then(() => {
          })
      } else {
          await Data.create({ _id:  interaction.user.id, t: 1 })
      }
      const d1 = await Data.findOne({ _id: gdatawith.id })
      if (d1) {
          await Data.findOneAndUpdate({ _id: gdatawith.id }, { t: d1.t+1}).then(() => {
          })
      } else {
          await Data.create({ _id:  gdata.id, t: 1 })
      }
      if (!gdatawith) return;
      if (interaction.message.id !== gdatawith.msgID) return;
      await interaction.deferReply({ ephemeral: true })
      let stusrgame = client.users.cache.get(gdatawith.id)
      let wthusrgame = client.users.cache.get(gdatawith.with)
      let nums = ["1", "2"]
      let numr = nums[Math.floor(Math.random() * nums.length)]
      let usrchoose = "";
      let notrole = "";
      if (numr == "1") {
        usrchoose = gdatawith.id;
        notrole = gdatawith.with;
      }
      if (numr == "2") {
        usrchoose = gdatawith.with;
        notrole = gdatawith.id;
      }
      gdatawith.time = timestamp(moment(ms("90s")) + Date.now())
      await gdatawith.save()
      interaction.editReply({ content: `> لقد تم القبول اللعبة هي : \`نرد\` ، اللعب مع : ${stusrgame} !!`, ephemeral: true })


      let embed_edit = new Discord.MessageEmbed()
        .setColor("BLACK")
        .setDescription(`>* تنبيه: في حال عدم استجابة الطرفين و عدم اكمال التحدي يؤدي الى خصم نصف المبلغ من الطرفين.
> عند التعادل لا يتم سحب اي مبلغ من الطرفين.*`)
        .addFields({ name: `- لـعبة الـ زهر  🎲 :`, value: `*__لديك ثلاث محاولات للحصول عـلي أعلي رقم و الفوز ، التعآدل ليس فوزاً .!__*` }, { name: `المبلغ:`, value: `__${parseInt(gdatawith.coins)}__` })


      let button_yes = new MessageButton()
        .setCustomId(`yesg_${gdatawith.msgID}`)
        .setLabel("قبول")
        .setStyle("SUCCESS")
        .setDisabled()

      let button_no = new MessageButton()
        .setCustomId(`nog_${gdatawith.msgID}`)
        .setLabel("رفض")
        .setStyle("DANGER")
        .setDisabled()

      let row = new MessageActionRow()
        .setComponents(button_yes, button_no)

      client.channels.cache.get(interaction.channel.id).messages.fetch(gdatawith.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit], components: [row] })).catch(err => console.error(err))

      let nrddata = await nrd.findOne({
        msgID: gdatawith.msgID
      })
      if (!nrddata) {


        nrdata = await nrd.create({
          msgID: gdatawith.msgID,
          idstusr: gdatawith.id,
          role: usrchoose,
          notrole: notrole,
          players: [stusrgame.id, wthusrgame.id]
        })


      } else {


        nrdata = await nrd.findOneAndUpdate({
          msgID: gdatawith.msgID,
          idstusr: gdatawith.id,
          role: usrchoose,
          notrole: notrole,
          players: [stusrgame.id, wthusrgame.id]
        })


      }






      let nrdusrdata = await nrdusr.findOne({
        id: gdatawith.id
      })

      if (!nrdusrdata) {

        nrdusrdata = await nrdusr.create({
          id: gdatawith.id,
          with: gdatawith.with,
          attempt: 0,
          numbers: [],
          result: 0
        })


      } else {


        nrdusrdata = await nrdusr.findOneAndUpdate({
          id: gdatawith.id,
          with: gdatawith.with,
          attempt: 0,
          numbers: [],
          result: 0
        })


      }



      let nrdusr1data = await nrdusr.findOne({
        id: gdatawith.with
      })
      if (!nrdusr1data) {
        nrdusr1data = await nrdusr.create({
          id: gdatawith.with,
          with: gdatawith.id,
          attempt: 0,
          numbers: [],
          result: 0
        })


      } else {


        nrdusr1data = await nrdusr.findOneAndUpdate({
          id: gdatawith.with,
          with: gdatawith.id,
          attempt: 0,
          numbers: [],
          result: 0
        })


      }
      setTimeout(async () => {
        let embed_edit_nrd_game = new Discord.MessageEmbed()
          .setTitle("بيانات التحدي")
          .addFields({ name: `${stusrgame.username}`, value: `0` }, { name: `${wthusrgame.username}`, value: `0` })
        let button_nrdk = new MessageButton()
          .setCustomId(`nrdk_${gdatawith.msgID}`)
          .setLabel("العب نردك")
          .setStyle("PRIMARY")
        let row = new MessageActionRow()
          .setComponents(button_nrdk)
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdatawith.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], content: `<@!${usrchoose}>\n اصبح دورك`, components: [row] })).catch(err => console.error(err))
      }, 3000)
      return;
    }
    if (interaction.customId == `cancel_${interaction.user.id}`) {
      let gdata = await game.findOne({
        id: interaction.user.id
      })
      if (!gdata) return;
      let stusrgame = client.users.cache.get(gdata.id)
      let wthusrgame = client.users.cache.get(gdata.with)
      client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
        embeds: [], content: `تم إلغاء التحدي من قبل ${interaction.user}
> || ${stusrgame} | ${wthusrgame} || `, components: []
      })).catch(err => console.error(err))
      await game.findOneAndDelete({
        id: stusrgame.id,
        with: wthusrgame.id,
        msgID: interaction.message.id
      })
      let data = await db.findOne({
        id: stusrgame.id
      })
      if (!data) {
        data = await db.create({
          id: stusrgame.id,
          coins: 0,
          status_playing: "no"
        })
      }
      let data2 = await db.findOne({
        id: wthusrgame.id
      })
      if (!data2) {
        data2 = await db.create({
          id: wthusrgame.id,
          coins: 0,
          status_playing: "no"
        })
      }
      data2.status_playing = "no";
      await data2.save()
      data.status_playing = "no";
      await data.save()
    }
    if (interaction.customId == `nog_${interaction.message.id}`) {
      let gdata = await game.findOne({
        msgID: interaction.message.id
      })
      if (!gdata) return;
      let stusrgame = client.users.cache.get(gdata.id)
      let wthusrgame = client.users.cache.get(gdata.with)
      if (stusrgame.id !== interaction.user.id && wthusrgame.id !== interaction.user.id) return;
      if (stusrgame.id == interaction.user.id) {
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
          embeds: [], content: `تم إلغاء التحدي من قبل ${interaction.user}
  > || ${stusrgame} | ${wthusrgame} || `, components: []
        })).catch(err => console.error(err))
      }
      if (wthusrgame.id == interaction.user.id) {
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
          embeds: [], content: `تم رفض التحدي من قبل ${interaction.user}
> || ${stusrgame} | ${wthusrgame} || `, components: []
        })).catch(err => console.error(err))
      }
      await game.findOneAndDelete({
        id: stusrgame.id,
        with: wthusrgame.id,
        msgID: interaction.message.id
      })
      let data = await db.findOne({
        id: stusrgame.id
      })
      if (!data) {
        data = await db.create({
          id: stusrgame.id,
          coins: 0,
          status_playing: "no"
        })
      }
      let data2 = await db.findOne({
        id: wthusrgame.id
      })
      if (!data2) {
        data2 = await db.create({
          id: wthusrgame.id,
          coins: 0,
          status_playing: "no"
        })
      }
      data2.status_playing = "no";
      await data2.save()
      data.status_playing = "no";
      await data.save()
    }
    if (interaction.customId == `nrdk_${interaction.message.id}`) {
      let data = await nrd.findOne({
        msgID: interaction.message.id
      })
      if (!data) return;
      let datausr = await nrdusr.findOne({
        id: interaction.user.id
      })
      if (!datausr) return;
      await interaction.deferReply({ ephemeral: true })
      if (data.role !== interaction.user.id && data.notrole == interaction.user.id) return interaction.editReply({ content: `> ليس عليك الدور !`, ephemeral: true })
      if (data.role !== interaction.user.id) return;
      let gdata = await game.findOne({
        id: data.idstusr
      })
      if (!gdata) return;
      let stusrgame = client.users.cache.get(data.idstusr)
      if (!stusrgame) return;
      let wthusrgame = client.users.cache.get(gdata.with)
      if (!wthusrgame) return;
      let nums = ["1", "2", "3", "4", "5", "6"]
      let num = nums[Math.floor(Math.random() * nums.length)]
      datausr.numbers.push(num)
      await datausr.save()
      datausr.result = parseInt(datausr.result) + parseInt(num)
      await datausr.save()
      datausr.attempt = parseInt(datausr.attempt) + 1;
      await datausr.save()
      gdata.time = timestamp(moment(ms("90s")) + Date.now())
      await gdata.save()
      interaction.editReply({ content: `> تم اللعب ، رقمك هو \`${num}\` !!`, ephemeral: true })
      let datausrus = await nrdusr.findOne({
        id: stusrgame.id
      })
      let datausrue = await nrdusr.findOne({
        id: wthusrgame.id
      })
      let resultnum1;
      if (datausrus.numbers.length == 2) resultnum1 = `${datausrus.numbers[0]} + ${datausrus.numbers[1]} = **${datausrus.result}**`;
      if (datausrus.numbers.length == 3) resultnum1 = `${datausrus.numbers[0]} + ${datausrus.numbers[1]} + ${datausrus.numbers[2]} = **${datausrus.result}**`;

      let resultnum2;
      if (datausrue.numbers.length == 2) resultnum2 = `${datausrue.numbers[0]} + ${datausrue.numbers[1]} = **${datausrue.result}**`;
      if (datausrue.numbers.length == 3) resultnum2 = `${datausrue.numbers[0]} + ${datausrue.numbers[1]} + ${datausrue.numbers[2]} = **${datausrue.result}**`;
      if (parseInt(datausr.attempt) == 1) {
        if (gdata.with == interaction.user.id) {
          let embed_edit_nrd_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrus.numbers[0] || 0}` }, { name: `${wthusrgame.tag}`, value: `> ${num}` })
          let button_nrdk = new MessageButton()
            .setCustomId(`nrdk_${gdata.msgID}`)
            .setLabel("العب نردك")
            .setStyle("DANGER")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_nrdk)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let button_nrdk1 = new MessageButton()
              .setCustomId(`nrdk_${gdata.msgID}`)
              .setLabel("العب نردك")
              .setStyle("SECONDARY")
            let row1 = new MessageActionRow()
              .setComponents(button_nrdk1)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], content: `${stusrgame}\n اصبح دورك`, components: [row1] })).catch(err => console.error(err))
          }, 2500)
        }
        if (data.idstusr == interaction.user.id) {
          let embed_edit_nrd_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .addFields({ name: `${stusrgame.tag}`, value: `> ${num}` }, { name: `${wthusrgame.tag}`, value: `> ${datausrue.numbers[0] || 0}` })
          let button_nrdk = new MessageButton()
            .setCustomId(`nrdk_${gdata.msgID}`)
            .setLabel("العب نردك")
            .setStyle("DANGER")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_nrdk)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let button_nrdk1 = new MessageButton()
              .setCustomId(`nrdk_${gdata.msgID}`)
              .setLabel("العب نردك")
              .setStyle("PRIMARY")
            let row1 = new MessageActionRow()
              .setComponents(button_nrdk1)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], content: `${wthusrgame}\n اصبح دورك`, components: [row1] })).catch(err => console.error(err))
          }, 2500)
        }
        return;
      }
      if (parseInt(datausr.attempt) == 2) {
        if (datausrus.numbers.length == 1) resultnum1 = `${datausrus.numbers[0]}`
        if (datausrue.numbers.length == 1) resultnum2 = `${datausrue.numbers[0]}`
        if (wthusrgame.id == interaction.user.id) {
          var datausrup = await nrdusr.findOne({
            id: interaction.user.id
          })
          let embed_edit_nrd_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${datausrue.numbers[0]} + ${datausrue.numbers[1]} = **${datausrue.result}**` })
          let button_nrdk = new MessageButton()
            .setCustomId(`nrdk_${gdata.msgID}`)
            .setLabel("العب نردك")
            .setStyle("DANGER")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_nrdk)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let button_nrdk1 = new MessageButton()
              .setCustomId(`nrdk_${gdata.msgID}`)
              .setLabel("العب نردك")
              .setStyle("SECONDARY")
            let row1 = new MessageActionRow()
              .setComponents(button_nrdk1)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], content: `${stusrgame}\n اصبح دورك`, components: [row1] })).catch(err => console.error(err))
          }, 2500)
        }
        if (stusrgame.id == interaction.user.id) {
          var datausrup = await nrdusr.findOne({
            id: interaction.user.id
          })
          let embed_edit_nrd_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
          let button_nrdk = new MessageButton()
            .setCustomId(`nrdk_${gdata.msgID}`)
            .setLabel("العب نردك")
            .setStyle("DANGER")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_nrdk)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let button_nrdk1 = new MessageButton()
              .setCustomId(`nrdk_${gdata.msgID}`)
              .setLabel("العب نردك")
              .setStyle("PRIMARY")
            let row1 = new MessageActionRow()
              .setComponents(button_nrdk1)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], content: `${wthusrgame}\n اصبح دورك`, components: [row1] })).catch(err => console.error(err))
          }, 2500)
        }
        return;
      }
      if (parseInt(datausr.attempt) == 3) {
        if (wthusrgame.id == interaction.user.id) {
          var datausrup = await nrdusr.findOne({
            id: interaction.user.id
          })
          let embed_edit_nrd_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
          let button_nrdk = new MessageButton()
            .setCustomId(`nrdk_${gdata.msgID}`)
            .setLabel("العب نردك")
            .setStyle("DANGER")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_nrdk)
          let datausrupst = await nrdusr.findOne({
            id: stusrgame.id
          })
          let datausrupwh = await nrdusr.findOne({
            id: wthusrgame.id
          })
          let embed_end_nrd_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
          if ((parseInt(datausrupst.attempt) == 3 && datausrupst.numbers.length == 3) && (parseInt(datausrupwh.attempt) == 3 && datausrupwh.numbers.length == 3)) {
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_end_nrd_game], content: `> انتهى التحدي...`, components: [] })).catch(err => console.error(err))
          } else {
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], components: [row] })).catch(err => console.error(err))
          }
          setTimeout(async () => {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            if ((parseInt(datausrupst.attempt) == 3 && datausrupst.numbers.length == 3) && (parseInt(datausrupwh.attempt) == 3 && datausrupwh.numbers.length == 3)) {
              let userr1r = await nrdusr.findOne({
                id: stusrgame.id
              })
              let userr2r = await nrdusr.findOne({
                id: wthusrgame.id
              })
              if (parseInt(userr1r.result) == parseInt(userr2r.result)) {
                let embed_end = new Discord.MessageEmbed()
                  .setTitle("بيانات التحدي")
                  .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
                client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_end], content: `${stusrgame} / ${wthusrgame} تعادل !\n اللعبة: النرد, المبلغ: **${gdata.coins}**` })).catch(err => console.error(err))
                let datacoinsusr1st = await db.findOne({
                  id: stusrgame.id
                })
  const d = await Data.findOne({ _id: stusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d.f) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f + 1, e: d.e + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: 1, e: coinsToAdd }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: wthusrgame.id });
if (d1.k) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k + 1, c: d1.c + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: 1, c: coinsToAdd }).then(async () => {
  });
}

                if (!datacoinsusr1st) {
                  datacoinsusr1st = await db.create({
                    id: stusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                let datacoinsusr2st = await db.findOne({
                  id: wthusrgame.id
                })
                if (!datacoinsusr2st) {
                  datacoinsusr = await db.create({
                    id: wthusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                datacoinsusr1st.status_playing = "no"
                await datacoinsusr1st.save()
                datacoinsusr2st.status_playing = "no"
                await datacoinsusr2st.save()
                await nrd.findOneAndDelete({
                  msgID: gdata.msgID,
                  idstusr: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: wthusrgame.id
                })
                await game.findOneAndDelete({
                  id: stusrgame.id,
                  with: wthusrgame.id
                })
              }
              if (parseInt(userr1r.result) > parseInt(userr2r.result)) {
                let embed_end = new Discord.MessageEmbed()
                  .setTitle("بيانات التحدي")
                  .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
                client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
                  embeds: [embed_end], content: `**${stusrgame}** الـ ** فـآئز ** : بـ ** مجموع ** :  **${parseInt(userr1r.result)}**  \n\n**${wthusrgame}** الـ ** خـآسر ** :  بـ ** مجموع ** : **${parseInt(userr2r.result)}** 
                    > الـ ** لعبة ** : الـ **النرد**,  الـ **:moneybag: - مبلغ **: **${gdata.coins}**`
                })).catch(err => console.error(err))
                let datacoinsusr1st = await db.findOne({
                  id: stusrgame.id
                })
             const d = await Data.findOne({ _id: stusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: wthusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

                if (!datacoinsusr1st) {
                  datacoinsusr1st = await db.create({
                    id: stusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                let tax = parseInt(gdata.coins) * 0.06;
                let total = parseInt(gdata.coins) - parseInt(tax);
                datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
                await datacoinsusr1st.save()
                let datacoinsusr2st = await db.findOne({
                  id: wthusrgame.id
                })
                if (!datacoinsusr2st) {
                  datacoinsusr = await db.create({
                    id: wthusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
                await datacoinsusr2st.save()
                datacoinsusr1st.status_playing = "no"
                await datacoinsusr1st.save()
                datacoinsusr2st.status_playing = "no"
                await datacoinsusr2st.save()
                await nrd.findOneAndDelete({
                  msgID: gdata.msgID,
                  idstusr: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: wthusrgame.id
                })
                await game.findOneAndDelete({
                  id: stusrgame.id,
                  with: wthusrgame.id
                })
              }

              if (parseInt(userr2r.result) > parseInt(userr1r.result)) {
                let embed_end = new Discord.MessageEmbed()
                  .setTitle("بيانات التحدي")
                  .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
                client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
                  embeds: [embed_end], content: `**${stusrgame}** الـ ** فـآئز ** : بـ ** مجموع ** :  **${parseInt(userr1r.result)}**  \n\n**${wthusrgame}** الـ ** خـآسر ** :  بـ ** مجموع ** : **${parseInt(userr2r.result)}** 
                    > الـ ** لعبة ** : الـ **النرد**,  الـ **:moneybag: - مبلغ **: **${gdata.coins}**`
                })).catch(err => console.error(err))
                let datacoinsusr1st = await db.findOne({
                  id: wthusrgame.id
                })

             const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

                if (!datacoinsusr1st) {
                  datacoinsusr1st = await db.create({
                    id: wthusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                let tax = parseInt(gdata.coins) * 0.06;
                let total = parseInt(gdata.coins) - parseInt(tax);
                datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
                await datacoinsusr1st.save()
                let datacoinsusr2st = await db.findOne({
                  id: stusrgame.id
                })
                if (!datacoinsusr2st) {
                  datacoinsusr2st = await db.create({
                    id: stusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
                await datacoinsusr2st.save()
                datacoinsusr1st.status_playing = "no"
                await datacoinsusr1st.save()
                datacoinsusr2st.status_playing = "no"
                await datacoinsusr2st.save()
                await nrd.findOneAndDelete({
                  msgID: gdata.msgID,
                  idstusr: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: wthusrgame.id
                })
                await game.findOneAndDelete({
                  id: stusrgame.id,
                  with: wthusrgame.id
                })
              }
              return;
            } else {
              let button_nrdk1 = new MessageButton()
                .setCustomId(`nrdk_${gdata.msgID}`)
                .setLabel("العب نردك")
                .setStyle("PRIMARY")
              let row1 = new MessageActionRow()
                .setComponents(button_nrdk1)
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], content: `${stusrgame}\n اصبح دورك`, components: [row1] })).catch(err => console.error(err))
            }
          }, 2500)
        }
        if (stusrgame.id == interaction.user.id) {
          var datausrupst = await nrdusr.findOne({
            id: interaction.user.id
          })
          let datausrupwh = await nrdusr.findOne({
            id: wthusrgame.id
          })
          let embed_edit_nrd_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
          let button_nrdk = new MessageButton()
            .setCustomId(`nrdk_${gdata.msgID}`)
            .setLabel("العب نردك")
            .setStyle("DANGER")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_nrdk)
          let embed_end_nrd_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
          if ((parseInt(datausrupst.attempt) == 3 && datausrupst.numbers.length == 3) && (parseInt(datausrupwh.attempt) == 3 && datausrupwh.numbers.length == 3)) {
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_end_nrd_game], content: `> انتهى التحدي...`, components: [] })).catch(err => console.error(err))
          } else {
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], components: [row] })).catch(err => console.error(err))
          }
          setTimeout(async () => {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            if ((parseInt(datausrupst.attempt) == 3 && datausrupst.numbers.length == 3) && (parseInt(datausrupwh.attempt) == 3 && datausrupwh.numbers.length == 3)) {
              let userr1r = await nrdusr.findOne({
                id: stusrgame.id
              })
              let userr2r = await nrdusr.findOne({
                id: wthusrgame.id
              })
              if (parseInt(userr1r.result) == parseInt(userr2r.result)) {
                let embed_end = new Discord.MessageEmbed()
                  .setTitle("بيانات التحدي")
                  .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
                client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_end], content: `${stusrgame} / ${wthusrgame} تعادل !\n اللعبة: النرد, المبلغ: **${gdata.coins}**` })).catch(err => console.error(err))
                let datacoinsusr1st = await db.findOne({
                  id: stusrgame.id
                })
                const d = await Data.findOne({ _id: stusrgame.id })
            if (d.t1) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(async () => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.t1) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
            }

                if (!datacoinsusr1st) {
                  datacoinsusr1st = await db.create({
                    id: stusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                let datacoinsusr2st = await db.findOne({
                  id: wthusrgame.id
                })
                if (!datacoinsusr2st) {
                  datacoinsusr = await db.create({
                    id: wthusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                datacoinsusr1st.status_playing = "no"
                await datacoinsusr1st.save()
                datacoinsusr2st.status_playing = "no"
                await datacoinsusr2st.save()
                await nrd.findOneAndDelete({
                  msgID: gdata.msgID,
                  idstusr: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: wthusrgame.id
                })
                await game.findOneAndDelete({
                  id: stusrgame.id,
                  with: wthusrgame.id
                })
              }
              if (parseInt(userr1r.result) > parseInt(userr2r.result)) {
                let embed_end = new Discord.MessageEmbed()
                  .setTitle("بيانات التحدي")
                  .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
                client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
                  embeds: [embed_end], content: `**${stusrgame}** الـ ** فـآئز ** : بـ ** مجموع ** :  **${parseInt(userr1r.result)}**  \n\n**${wthusrgame}** الـ ** خـآسر ** :  بـ ** مجموع ** : **${parseInt(userr2r.result)}** 
                    > الـ ** لعبة ** : الـ **النرد**,  الـ **:moneybag: - مبلغ **: **${gdata.coins}**`
                })).catch(err => console.error(err))
                let datacoinsusr1st = await db.findOne({
                  id: stusrgame.id
                })
                const d = await Data.findOne({ _id: stusrgame.id });
                const coinsToAdd = parseInt(gdata.coins);
                if (d?.f) {
                    await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
                    });
                } else {
                    await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
                    });
                }

                const d1 = await Data.findOne({ _id: wthusrgame.id });
                if (d1?.k) {
                    await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
                    });
                } else {
                    await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
                    });
                }
                if (!datacoinsusr1st) {
                  datacoinsusr1st = await db.create({
                    id: stusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                let tax = parseInt(gdata.coins) * 0.06;
                let total = parseInt(gdata.coins) - parseInt(tax);
                datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
                await datacoinsusr1st.save()
                let datacoinsusr2st = await db.findOne({
                  id: wthusrgame.id
                })
                if (!datacoinsusr2st) {
                  datacoinsusr = await db.create({
                    id: wthusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
                await datacoinsusr2st.save()
                datacoinsusr1st.status_playing = "no"
                await datacoinsusr1st.save()
                datacoinsusr2st.status_playing = "no"
                await datacoinsusr2st.save()
                await nrd.findOneAndDelete({
                  msgID: gdata.msgID,
                  idstusr: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: wthusrgame.id
                })
                await game.findOneAndDelete({
                  id: stusrgame.id,
                  with: wthusrgame.id
                })
              }
              if (parseInt(userr2r.result) > parseInt(userr1r.result)) {
                let embed_end = new Discord.MessageEmbed()
                  .setTitle("بيانات التحدي")
                  .addFields({ name: `${stusrgame.tag}`, value: `> ${resultnum1}` }, { name: `${wthusrgame.tag}`, value: `> ${resultnum2}` })
                client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
                  embeds: [embed_end], content: `**${stusrgame}** الـ ** فـآئز ** : بـ ** مجموع ** :  **${parseInt(userr1r.result)}**  \n\n**${wthusrgame}** الـ ** خـآسر ** :  بـ ** مجموع ** : **${parseInt(userr2r.result)}** 
                    > الـ ** لعبة ** : الـ **النرد**,  الـ **:moneybag: - مبلغ **: **${gdata.coins}**`
                })).catch(err => console.error(err))
                let datacoinsusr1st = await db.findOne({
                  id: wthusrgame.id
                })
             const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

                if (!datacoinsusr1st) {
                  datacoinsusr1st = await db.create({
                    id: wthusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                let tax = parseInt(gdata.coins) * 0.06;
                let total = parseInt(gdata.coins) - parseInt(tax);
                datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
                await datacoinsusr1st.save()
                let datacoinsusr2st = await db.findOne({
                  id: stusrgame.id
                })
                if (!datacoinsusr2st) {
                  datacoinsusr2st = await db.create({
                    id: stusrgame.id,
                    coins: 0,
                    status_playing: "no"
                  })
                }
                datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
                await datacoinsusr2st.save()
                datacoinsusr1st.status_playing = "no"
                await datacoinsusr1st.save()
                datacoinsusr2st.status_playing = "no"
                await datacoinsusr2st.save()
                await nrd.findOneAndDelete({
                  msgID: gdata.msgID,
                  idstusr: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: stusrgame.id
                })
                await nrdusr.findOneAndDelete({
                  id: wthusrgame.id
                })
                await game.findOneAndDelete({
                  id: stusrgame.id,
                  with: wthusrgame.id
                })
              }
              return;
            } else {
              let button_nrdk1 = new MessageButton()
                .setCustomId(`nrdk_${gdata.msgID}`)
                .setLabel("العب نردك")
                .setStyle("PRIMARY")
              let row1 = new MessageActionRow()
                .setComponents(button_nrdk1)
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], content: `${wthusrgame}\n اصبح دورك`, components: [row1] })).catch(err => console.error(err))
            }
          }, 2500)
        }
        return;
      }
    }
    if (interaction.customId == `takribi_${interaction.user.id}`) {

      let gdata = await game.findOne({
        id: interaction.user.id
      })

      if (!gdata) return;
      if (!gdata.coins || gdata.coins == null) return;
      if (!gdata.with || gdata.with == null) return;
      if (!gdata.msgID || gdata.msgID == null) return;
      gdata.game = "takribi"
      await gdata.save()
      await interaction.deferReply({ ephemeral: true })
      let usraccano = interaction.guild.members.cache.find(s => s.id == gdata.with)
      if (!usraccano) return interaction.reply({ content: `\`❎\` **لم استطيع إجاد صديقك في الخادم**`, ephemeral: true })
      gdata.time = timestamp(moment(ms("40s")) + Date.now())
      await gdata.save()
      let embed_edit = new Discord.MessageEmbed()
        .setColor("BLACK")
        .setDescription(`> تنبيه: في حال عدم استجابة الطرفين و عدم اكمال* التحدي يؤدي الى خصم نصف المبلغ من الطرفين.
    > عند التعادل لا يتم سحب اي مبلغ من الطرفين.*`)
        .addFields({ name: `- لـعبة الـ تقريبي 📊 :`, value: `*__سيظهر لك ارقام عشوائيه و يجب عليك اختيار بين اقل نتيجه او اكبر نتيجه , للحصول علي الحد الاقصي او اقرب رقم له , قد يكون الحظ حليفك او لا . التعادل ليس فوزا .!
__*` }, { name: `المبلغ:`, value: `${parseInt(gdata.coins)}` })


      let button_yes = new MessageButton()
        .setCustomId(`yestkg_${gdata.msgID}`)
        .setLabel("قبول")
        .setStyle("SUCCESS")

      let button_no = new MessageButton()
        .setCustomId(`notkg_${gdata.msgID}`)
        .setLabel("رفض")
        .setStyle("DANGER")

      let row = new MessageActionRow()
        .setComponents(button_yes, button_no)

      interaction.editReply({ content: `> لقد تم اختيار العبة هي : \`الرقم التقريبي\` !!`, ephemeral: true })
      client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit], content: `> بانتظار رد من ${usraccano} ...`, components: [row] })).catch(err => console.error(err))
    }
    if (interaction.customId == `yestkg_${interaction.message.id}`) {
      let gdatawith = await game.findOne({
        with: interaction.user.id
      })
      const dd = await Data.findOne({ _id: interaction.user.id })
      if (dd) {
          await Data.findOneAndUpdate({ _id: interaction.user.id }, { t: dd.t+1}).then(() => {
          })
      } else {
          await Data.create({ _id:  interaction.user.id, t: 1 })
      }
      const d1 = await Data.findOne({ _id: gdatawith.id })
      if (d1) {
          await Data.findOneAndUpdate({ _id: gdatawith.id }, { t: d1.t+1}).then(() => {
          })
      } else {
          await Data.create({ _id:  gdatawith.id, t: 1 })
      }
      if (!gdatawith) return;
      if (interaction.message.id !== gdatawith.msgID) return;
      await interaction.deferReply({ ephemeral: true })
      let stusrgame = client.users.cache.get(gdatawith.id)
      let wthusrgame = client.users.cache.get(gdatawith.with)
      let nums = ["1", "2"]
      let numr = nums[Math.floor(Math.random() * nums.length)]
      let usrchoose = "";
      let notrole = "";
      if (numr == "1") {
        usrchoose = gdatawith.id;
        notrole = gdatawith.with;
        statusuingame1 = "**Playing..**";
        statusuingame2 = "Waiting.."
      }
      if (numr == "2") {
        usrchoose = gdatawith.with;
        notrole = gdatawith.id;
        statusuingame1 = "Waiting..";
        statusuingame2 = "**Playing..**"
      }
      gdatawith.time = timestamp(moment(ms("90s")) + Date.now())
      await gdatawith.save()
      interaction.editReply({ content: `> لقد تم القبول اللعبة هي : \`الرقم التقريبي\` ، اللعب مع : ${stusrgame} !!`, ephemeral: true })
      const firstNumbers = [];
      for (let i = 19; i <= 79; i += 3) {
        firstNumbers.push(i);
      }

      const secondNumbers = [2, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 7];
      const thirdNumbers = [4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14];
      const fourthNumbers = [5, 6, 6, 7, 8, 8, 9, 10, 10, 11, 12, 12, 13, 14, 15, 15, 16, 16, 17, 18, 18, 19];
      const fiveNumbers = [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 22, 22, 23, 24, 25, 26, 27];


      const randomIndex = Math.floor(Math.random() * firstNumbers.length);
      const a = secondNumbers[randomIndex];
      const b = thirdNumbers[randomIndex];
      const c = fourthNumbers[randomIndex];
      const d = fiveNumbers[randomIndex]
      const numaksa = firstNumbers[randomIndex];
      setTimeout(async () => {
        let embed_edit_nrd_game = new Discord.MessageEmbed()
          .setTitle("بيانات التحدي")
          .setDescription(`اقصى رقم : **${numaksa}**`)
          .addFields({ name: `${stusrgame.tag}`, value: `> ${statusuingame1}` }, { name: `${wthusrgame.tag}`, value: `> ${statusuingame2}` })
        let button_arkam1 = new MessageButton()
          .setCustomId(`arkam1tk_${gdatawith.msgID}`)
          .setLabel(`${a} - ${b}`)
          .setStyle("PRIMARY")
        let button_finish = new MessageButton()
          .setCustomId(`finishtk_${gdatawith.msgID}`)
          .setLabel("finish")
          .setStyle("SUCCESS")
        let button_arkam2 = new MessageButton()
          .setCustomId(`arkam2tk_${gdatawith.msgID}`)
          .setLabel(`${c} - ${d}`)
          .setStyle("PRIMARY")
        let row = new MessageActionRow()
          .setComponents(button_arkam1, button_finish, button_arkam2)
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdatawith.msgID).then(msg1 => msg1.edit({ embeds: [embed_edit_nrd_game], content: `<@!${usrchoose}>\n انه دورك`, components: [row] })).catch(err => console.error(err))
      }, 1250)



      let tkdata = await takribi.findOne({
        msgID: gdatawith.msgID
      })
      if (!tkdata) {


        tkdata = await takribi.create({
          msgID: gdatawith.msgID,
          idstusr: gdatawith.id,
          role: usrchoose,
          notrole: notrole,
          max_number: numaksa,
          number_players_done: 0,
          number_smaller1: a,
          number_smaller2: b,
          number_greater1: c,
          number_greater2: d
        })


      } else {


        tkdata = await takribi.findOneAndUpdate({
          msgID: gdatawith.msgID,
          idstusr: gdatawith.id,
          role: usrchoose,
          notrole: notrole,
          max_number: numaksa,
          number_players_done: 0,
          number_smaller1: a,
          number_smaller2: b,
          number_greater1: c,
          number_greater2: d
        })


      }






      let tkusrdata = await tkusr.findOne({
        id: gdatawith.id
      })

      if (!tkusrdata) {

        tkusrdata = await tkusr.create({
          id: gdatawith.id,
          with: gdatawith.with,
          attempt: 0,
          numbers: [],
          result: 0,
          msgID: interaction.message.id
        })


      } else {


        tkusrdata = await tkusr.findOneAndUpdate({
          id: gdatawith.id,
          with: gdatawith.with,
          attempt: 0,
          numbers: [],
          result: 0,
          msgID: interaction.message.id
        })


      }



      let tkusr1data = await tkusr.findOne({
        id: gdatawith.with
      })
      if (!tkusr1data) {
        tkusr1data = await tkusr.create({
          id: gdatawith.with,
          with: gdatawith.id,
          attempt: 0,
          numbers: [],
          result: 0,
          msgID: interaction.message.id
        })


      } else {


        tkusr1data = await tkusr.findOneAndUpdate({
          id: gdatawith.with,
          with: gdatawith.id,
          attempt: 0,
          numbers: [],
          result: 0,
          msgID: interaction.message.id
        })


      }
      return;
    }
    if (interaction.customId == `notkg_${interaction.message.id}`) {
      let gdata = await game.findOne({
        msgID: interaction.message.id
      })
      if (!gdata) return;
      let stusrgame = client.users.cache.get(gdata.id)
      let wthusrgame = client.users.cache.get(gdata.with)
      if (stusrgame.id !== interaction.user.id && wthusrgame.id !== interaction.user.id) return;
      if (stusrgame.id == interaction.user.id) {
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
          embeds: [], content: `تم إلغاء التحدي من قبل ${interaction.user}
            > || ${stusrgame} | ${wthusrgame} || `, components: []
        })).catch(err => console.error(err))
      }
      if (wthusrgame.id == interaction.user.id) {
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
          embeds: [], content: `تم رفض التحدي من قبل ${interaction.user}
         > || ${stusrgame} | ${wthusrgame} || `, components: []
        })).catch(err => console.error(err))
      }
      await game.findOneAndDelete({
        id: stusrgame.id,
        with: wthusrgame.id,
        msgID: interaction.message.id
      })
      let data = await db.findOne({
        id: stusrgame.id
      })
      if (!data) {
        data = await db.create({
          id: stusrgame.id,
          coins: 0,
          status_playing: "no"
        })
      }
      let data2 = await db.findOne({
        id: wthusrgame.id
      })
      if (!data2) {
        data2 = await db.create({
          id: wthusrgame.id,
          coins: 0,
          status_playing: "no"
        })
      }
      data2.status_playing = "no";
      await data2.save()
      data.status_playing = "no";
      await data.save()
    }
    if (interaction.customId == `finishtk_${interaction.message.id}`) {
      let data = await takribi.findOne({
        msgID: interaction.message.id
      })
      if (!data) return;
      let datausr = await tkusr.findOne({
        id: interaction.user.id,
        msgID: interaction.message.id
      })
      if (!datausr) return;
      await interaction.deferReply({ ephemeral: true })
      if (data.role !== interaction.user.id && data.notrole == interaction.user.id) return interaction.editReply({ content: `انه ليس دورك !`, ephemeral: true })
      if (data.role !== interaction.user.id) return;
      let gdata = await game.findOne({
        id: data.idstusr,
        msgID: interaction.message.id
      })
      if (!gdata) return;
      let stusrgame = client.users.cache.get(data.idstusr)
      if (!stusrgame) return;
      let wthusrgame = client.users.cache.get(gdata.with)
      if (!wthusrgame) return;
      data.number_players_done = parseInt(data.number_players_done) + 1;
      await data.save()
      let dataup = await takribi.findOne({
        msgID: interaction.message.id
      })
      if (!dataup) return;
      gdata.time = timestamp(moment(ms("90s")) + Date.now())
      await gdata.save()
      if (parseInt(dataup.number_players_done) == 1) {
        if (data.notrole == stusrgame.id) {
          data.role = stusrgame.id;
          await data.save()
          data.notrole = wthusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          interaction.editReply({ content: `> تم الانتهاء من اللعب، انتظر العضو حتى يلعب دوره !`, ephemeral: true })
          return;
        }
        if (data.notrole == wthusrgame.id) {
          data.role = wthusrgame.id;
          await data.save()
          data.notrole = stusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          interaction.editReply({ content: `> تم الانتهاء من اللعب، انتظر العضو حتى يلعب دوره !`, ephemeral: true })
          return;
        }
      }
      let datausrtk1 = await tkusr.findOne({
        id: stusrgame.id,
        with: wthusrgame.id,
        msgID: interaction.message.id
      })
      if (!datausrtk1) return;
      let datausrtk2 = await tkusr.findOne({
        id: wthusrgame.id,
        with: stusrgame.id,
        msgID: interaction.message.id
      })
      if (!datausrtk2) return;
      if (parseInt(dataup.number_players_done) == 2) {
        let embed_finish_tk_game = new Discord.MessageEmbed()
          .setTitle("بيانات التحدي")
          .setDescription(`اقصى رقم : **${dataup.max_number}**`)
          .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
        let button_arkam1 = new MessageButton()
          .setCustomId(`arkam1tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let button_finish = new MessageButton()
          .setCustomId(`finishtk_${gdata.msgID}`)
          .setLabel("finish")
          .setStyle("SUCCESS")
          .setDisabled()
        let button_arkam2 = new MessageButton()
          .setCustomId(`arkam2tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let row = new MessageActionRow()
          .setComponents(button_arkam1, button_finish, button_arkam2)
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
        setTimeout(async () => {
          if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** : ${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
           const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            const d = await Data.findOne({ _id: stusrgame.id })
            if (d.t1) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.t1) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
            }
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} ** الـ ** فـآئز ** : بـ ** مجموع ** : ${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            const d = await Data.findOne({ _id: stusrgame.id })
            if (d.f) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f+1 , e: d.e+parseInt(gdata.coins)}).then(async () => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id }, { f: 1 , e: parseInt(gdata.coins)}).then(async () => {
                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.k) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k+1, c:d1.c+gdata.coins}).then(async () => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { k: 1 , c: parseInt(gdata.coins)}).then(async () => {
                })
            }
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
const d = await Data.findOne({ _id: stusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d.f) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f + 1, e: d.e + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: 1, e: coinsToAdd }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: wthusrgame.id });
if (d1.k) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k + 1, c: d1.c + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: 1, c: coinsToAdd }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
         const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
        }, 1500)
        return;
      }
    }



    if (interaction.customId == `arkam1tk_${interaction.message.id}`) {
      let data = await takribi.findOne({
        msgID: interaction.message.id
      })
      if (!data) return;
      let datausr = await tkusr.findOne({
        id: interaction.user.id,
        msgID: interaction.message.id
      })
      if (!datausr) return;
      await interaction.deferReply({ ephemeral: true })
      if (data.role !== interaction.user.id && data.notrole == interaction.user.id) return interaction.editReply({ content: `انه ليس دورك !`, ephemeral: true })
      if (data.role !== interaction.user.id) return;
      let gdata = await game.findOne({
        id: data.idstusr,
        msgID: interaction.message.id
      })
      if (!gdata) return;
      let stusrgame = client.users.cache.get(data.idstusr)
      if (!stusrgame) return;
      let wthusrgame = client.users.cache.get(gdata.with)
      if (!wthusrgame) return;
      let dataup = await takribi.findOne({
        msgID: interaction.message.id
      })
      if (!dataup) return;
      gdata.time = timestamp(moment(ms("90s")) + Date.now())
      await gdata.save()
      let urnum = getRandomNumber(parseInt(data.number_smaller1), parseInt(data.number_smaller2))
      datausr.numbers.push(urnum)
      await datausr.save()
      datausr.result = parseInt(datausr.result) + urnum;
      await datausr.save()
      let datausrup = await tkusr.findOne({
        id: interaction.user.id,
        msgID: interaction.message.id
      })
      if (!datausrup) return;
      let datausrtk1 = await tkusr.findOne({
        id: stusrgame.id,
        with: wthusrgame.id,
        msgID: interaction.message.id
      })
      if (!datausrtk1) return;
      let datausrtk2 = await tkusr.findOne({
        id: wthusrgame.id,
        with: stusrgame.id,
        msgID: interaction.message.id
      })
      if (!datausrtk2) return;
      if ((parseInt(data.max_number) < parseInt(datausrup.result))) {
        data.number_players_done = parseInt(data.number_players_done) + 1
        await data.save()
        datausrup = await tkusr.findOne({
          id: interaction.user.id,
          msgID: interaction.message.id
        })
        datausrtk1 = await tkusr.findOne({
          id: stusrgame.id,
          with: wthusrgame.id,
          msgID: interaction.message.id
        })
        datausrtk2 = await tkusr.findOne({
          id: wthusrgame.id,
          with: stusrgame.id,
          msgID: interaction.message.id
        })
        dataup = await takribi.findOne({
          msgID: interaction.message.id
        })
        if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
          if (data.notrole == stusrgame.id) {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                     اصبح مجموعك ${datausrup.result}\n
                      > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          if (data.notrole == wthusrgame.id) {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                      اصبح مجموعك ${datausrup.result}\n
                      > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
        }

        if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
          if (data.notrole == stusrgame.id) {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                            اصبح مجموعك${datausrup.result}\n
                      > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          if (data.notrole == wthusrgame.id) {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**           
                            اصبح مجموعك${datausrup.result}
                     > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          return;
        }





        if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
          interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
            .setDisabled()
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
              if (d.t1) {
                  await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                  })
              }
              const d1 = await Data.findOne({ _id: wthusrgame.id })
              if (d1.t1) {
                  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
              }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
          }, 1500)
          return;
        }
        if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
          interaction.editReply({
            content: `لقد حصلت على **${urnum}**
                    اصبح مجموعك ${datausrup.result}\n
                    > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
            .setDisabled()
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}


              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
              if (d.t1) {
                  await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                  })
              }
              const d1 = await Data.findOne({ _id: wthusrgame.id })
              if (d1.t1) {
                  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
              }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
           const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
          }, 1500)
        }
      }
      if ((parseInt(data.max_number) == parseInt(datausrup.result))) {
        data.number_players_done = parseInt(data.number_players_done) + 1
        await data.save()
        datausrup = await tkusr.findOne({
          id: interaction.user.id,
          msgID: interaction.message.id
        })
        datausrtk1 = await tkusr.findOne({
          id: stusrgame.id,
          with: wthusrgame.id,
          msgID: interaction.message.id
        })
        datausrtk2 = await tkusr.findOne({
          id: wthusrgame.id,
          with: stusrgame.id,
          msgID: interaction.message.id
        })
        dataup = await takribi.findOne({
          msgID: interaction.message.id
        })
        if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
          if (data.notrole == stusrgame.id) {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                        اصبح مجموعك ${datausrup.result}\n
                        > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          if (data.notrole == wthusrgame.id) {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                        اصبح مجموعك ${datausrup.result}\n
                        > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
        }

        if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
          if (data.notrole == stusrgame.id) {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                        اصبح مجموعك ${datausrup.result}\n
                        > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          if (data.notrole == wthusrgame.id) {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                        اصبح مجموعك ${datausrup.result}\n
                        > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          return;
        }





        if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
          interaction.editReply({
            content: `لقد حصلت على **${urnum}**
              اصبح مجموعك ${datausrup.result}\n
              > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
            .setDisabled()
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
            if (d.t1) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.t1) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
            }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
              if (d.f) {
                  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f+1 , e: d.e+parseInt(gdata.coins)}).then(async () => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  stusrgame.id }, { f: 1 , e: parseInt(gdata.coins)}).then(async () => {
                  })
              }
              const d1 = await Data.findOne({ _id: wthusrgame.id })
              if (d1.k) {
                  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k+1, c:d1.c+gdata.coins}).then(async () => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { k: 1 , c: parseInt(gdata.coins)}).then(async () => {
                  })
              }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
              if (d.f) {
                  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f+1 , e: d.e+parseInt(gdata.coins)}).then(async () => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  stusrgame.id }, { f: 1 , e: parseInt(gdata.coins)}).then(async () => {
                  })
              }
              const d1 = await Data.findOne({ _id: wthusrgame.id })
              if (d1.k) {
                  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k+1, c:d1.c+gdata.coins}).then(async () => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { k: 1 , c: parseInt(gdata.coins)}).then(async () => {
                  })
              }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}


              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
          }, 1500)
          return;
        }
        if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
          interaction.editReply({
            content: `لقد حصلت على **${urnum}**
                      اصبح مجموعك ${datausrup.result}\n
                      > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
            .setDisabled()
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
              if (d.t1) {
                  await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                  })
              }
              const d1 = await Data.findOne({ _id: wthusrgame.id })
              if (d1.t1) {
                  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
              }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {

                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
          }, 1500)
        }
      }
      if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
        if (data.notrole == stusrgame.id) {
          data.role = stusrgame.id;
          await data.save()
          data.notrole = wthusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          return interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
        }
        if (data.notrole == wthusrgame.id) {
          data.role = wthusrgame.id;
          await data.save()
          data.notrole = stusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          return interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
        }
      }

      if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
        if (data.notrole == stusrgame.id) {
          data.role = stusrgame.id;
          await data.save()
          data.notrole = wthusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          return interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
        }
        if (data.notrole == wthusrgame.id) {
          data.role = wthusrgame.id;
          await data.save()
          data.notrole = stusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          return interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
        }
        return;
      }





      if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
        interaction.editReply({
          content: `لقد حصلت على **${urnum}**
  اصبح مجموعك ${datausrup.result}\n
  > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
        })
        let embed_finish_tk_game = new Discord.MessageEmbed()
          .setTitle("بيانات التحدي")
          .setDescription(`اقصى رقم : **${dataup.max_number}**`)
          .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
        let button_arkam1 = new MessageButton()
          .setCustomId(`arkam1tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let button_finish = new MessageButton()
          .setCustomId(`finishtk_${gdata.msgID}`)
          .setLabel("finish")
          .setStyle("SUCCESS")
          .setDisabled()
        let button_arkam2 = new MessageButton()
          .setCustomId(`arkam2tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let row = new MessageActionRow()
          .setComponents(button_arkam1, button_finish, button_arkam2)
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
        setTimeout(async () => {
          if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
           const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

            if (!datacoinsusr1st) {

              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            const d = await Data.findOne({ _id: stusrgame.id })
            if (d.t1) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.t1) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
            }
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
const d = await Data.findOne({ _id: stusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d.f) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f + 1, e: d.e + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: 1, e: coinsToAdd }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: wthusrgame.id });
if (d1.k) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k + 1, c: d1.c + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: 1, c: coinsToAdd }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
        }, 1500)
        return;
      }
      if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
        interaction.editReply({
          content: `لقد حصلت على **${urnum}**
          اصبح مجموعك ${datausrup.result}\n
          > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
        })
        let embed_finish_tk_game = new Discord.MessageEmbed()
          .setTitle("بيانات التحدي")
          .setDescription(`اقصى رقم : **${dataup.max_number}**`)
          .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
        let button_arkam1 = new MessageButton()
          .setCustomId(`arkam1tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let button_finish = new MessageButton()
          .setCustomId(`finishtk_${gdata.msgID}`)
          .setLabel("finish")
          .setStyle("SUCCESS")
          .setDisabled()
        let button_arkam2 = new MessageButton()
          .setCustomId(`arkam2tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let row = new MessageActionRow()
          .setComponents(button_arkam1, button_finish, button_arkam2)
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
        setTimeout(async () => {
          if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
           const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            const d = await Data.findOne({ _id: stusrgame.id })
            if (d.t1) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.t1) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
            }
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
const d = await Data.findOne({ _id: stusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d.f) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f + 1, e: d.e + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: 1, e: coinsToAdd }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: wthusrgame.id });
if (d1.k) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k + 1, c: d1.c + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: 1, c: coinsToAdd }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
const d = await Data.findOne({ _id: stusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d.f) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: d.f + 1, e: d.e + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { f: 1, e: coinsToAdd }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: wthusrgame.id });
if (d1.k) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: d1.k + 1, c: d1.c + coinsToAdd }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { k: 1, c: coinsToAdd }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
         const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
        }, 1000)
        return;
      }
      return interaction.editReply({
        content: `لقد حصلت على **${urnum}**
اصبح مجموعك ${datausrup.result}
||تنبيه: انتبه ان يصبح.  مجموعك اعلى من الرقم المطلوب،  يمكنك انهاء دورك بالضغط على الزر الاخضر||`, ephemeral: true
      })
    }




















    if (interaction.customId == `arkam2tk_${interaction.message.id}`) {
      let data = await takribi.findOne({
        msgID: interaction.message.id
      })
      if (!data) return;
      let datausr = await tkusr.findOne({
        id: interaction.user.id,
        msgID: interaction.message.id
      })
      if (!datausr) return;
      await interaction.deferReply({ ephemeral: true })
      if (data.role !== interaction.user.id && data.notrole == interaction.user.id) return interaction.editReply({ content: `انه ليس دورك !`, ephemeral: true })
      if (data.role !== interaction.user.id) return;
      let gdata = await game.findOne({
        id: data.idstusr,
        msgID: interaction.message.id
      })
      if (!gdata) return;
      let stusrgame = client.users.cache.get(data.idstusr)
      if (!stusrgame) return;
      let wthusrgame = client.users.cache.get(gdata.with)
      if (!wthusrgame) return;
      data.number_players_done = parseInt(data.number_players_done) + 1;
      let dataup = await takribi.findOne({
        msgID: interaction.message.id
      })
      if (!dataup) return;
      gdata.time = timestamp(moment(ms("90s")) + Date.now())
      await gdata.save()
      let urnum = getRandomNumber(parseInt(data.number_greater1), parseInt(data.number_greater2))
      datausr.numbers.push(urnum)
      await datausr.save()
      datausr.result = parseInt(datausr.result) + urnum;
      await datausr.save()
      let datausrup = await tkusr.findOne({
        id: interaction.user.id,
        msgID: interaction.message.id
      })
      if (!datausrup) return;
      let datausrtk1 = await tkusr.findOne({
        id: stusrgame.id,
        with: wthusrgame.id,
        msgID: interaction.message.id
      })
      if (!datausrtk1) return;
      let datausrtk2 = await tkusr.findOne({
        id: wthusrgame.id,
        with: stusrgame.id,
        msgID: interaction.message.id
      })
      if (!datausrtk2) return;
      if ((parseInt(data.max_number) < parseInt(datausrup.result))) {
        data.number_players_done = parseInt(data.number_players_done) + 1
        await data.save()
        datausrup = await tkusr.findOne({
          id: interaction.user.id,
          msgID: interaction.message.id
        })
        datausrtk1 = await tkusr.findOne({
          id: stusrgame.id,
          with: wthusrgame.id,
          msgID: interaction.message.id
        })
        datausrtk2 = await tkusr.findOne({
          id: wthusrgame.id,
          with: stusrgame.id,
          msgID: interaction.message.id
        })
        dataup = await takribi.findOne({
          msgID: interaction.message.id
        })
        if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
          if (data.notrole == stusrgame.id) {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                            اصبح مجموعك${datausrup.result}\n
                        > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          if (data.notrole == wthusrgame.id) {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                            اصبح  مجموعك ${datausrup.result}
                        > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
        }

        if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
          if (data.notrole == stusrgame.id) {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                            اصبح مجموعك${datausrup.result}\n
                        > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          if (data.notrole == wthusrgame.id) {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                                                            اصبح مجموعك${datausrup.result}
                        > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          return;
        }





        if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
          interaction.editReply({
            content: `لقد حصلت على **${urnum}**    

                             اصبح مجموعك ${datausrup.result}\n
              > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
            .setDisabled()
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({
                embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :
${datausrtk2.result} 

نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** 

نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: 

**${parseInt(gdata.coins).toLocaleString()}**`, components: []
              })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}


              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
            if (d.t1) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.t1) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
            }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
          }, 1500)
          return;
        }
        if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
          interaction.editReply({
            content: `لقد حصلت على **${urnum}**
اصبح مجموعك ${datausrup.result}\n
> تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
            .setDisabled()
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
            if (d.t1) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.t1) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
            }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
          }, 1500)
        }
      }
      if ((parseInt(data.max_number) == parseInt(datausrup.result))) {
        data.number_players_done = parseInt(data.number_players_done) + 1
        await data.save()
        datausrup = await tkusr.findOne({
          id: interaction.user.id,
          msgID: interaction.message.id
        })
        datausrtk1 = await tkusr.findOne({
          id: stusrgame.id,
          with: wthusrgame.id,
          msgID: interaction.message.id
        })
        datausrtk2 = await tkusr.findOne({
          id: wthusrgame.id,
          with: stusrgame.id,
          msgID: interaction.message.id
        })
        dataup = await takribi.findOne({
          msgID: interaction.message.id
        })
        if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
          if (data.notrole == stusrgame.id) {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                          اصبح مجموعك ${datausrup.result}\n
                          > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          if (data.notrole == wthusrgame.id) {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                          اصبح مجموعك ${datausrup.result}\n
                          > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
        }

        if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
          if (data.notrole == stusrgame.id) {
            data.role = stusrgame.id;
            await data.save()
            data.notrole = wthusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                          اصبح مجموعك ${datausrup.result}\n
                          > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          if (data.notrole == wthusrgame.id) {
            data.role = wthusrgame.id;
            await data.save()
            data.notrole = stusrgame.id;
            await data.save()
            let embed_finish_tk_game = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
            let button_arkam1 = new MessageButton()
              .setCustomId(`arkam1tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
              .setStyle("PRIMARY")
            let button_finish = new MessageButton()
              .setCustomId(`finishtk_${gdata.msgID}`)
              .setLabel("finish")
              .setStyle("SUCCESS")
            let button_arkam2 = new MessageButton()
              .setCustomId(`arkam2tk_${gdata.msgID}`)
              .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
              .setStyle("PRIMARY")
            let row = new MessageActionRow()
              .setComponents(button_arkam1, button_finish, button_arkam2)
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
            return interaction.editReply({
              content: `لقد حصلت على **${urnum}**
                          اصبح مجموعك ${datausrup.result}\n
                          > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
            })
          }
          return;
        }





        if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
          interaction.editReply({
            content: `لقد حصلت على **${urnum}**
                اصبح مجموعك ${datausrup.result}\n
                > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
            .setDisabled()
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
            .setDisabled()
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
          setTimeout(async () => {
            if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
              const d = await Data.findOne({ _id: stusrgame.id })
              if (d.t1) {
                  await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                  })
              }
              const d1 = await Data.findOne({ _id: wthusrgame.id })
              if (d1.t1) {
                  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                  })
              } else {
                  await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
              }
              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
            if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
              let embed_finish_tk_game_tm = new Discord.MessageEmbed()
                .setTitle("بيانات التحدي")
                .setDescription(`اقصى رقم : **${dataup.max_number}**`)
                .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
              client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
              let datacoinsusr1st = await db.findOne({
                id: stusrgame.id
              })
                const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

              if (!datacoinsusr1st) {
                datacoinsusr1st = await db.create({
                  id: stusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
              await datacoinsusr1st.save()
              let datacoinsusr2st = await db.findOne({
                id: wthusrgame.id
              })
              if (!datacoinsusr2st) {
                datacoinsusr = await db.create({
                  id: wthusrgame.id,
                  coins: 0,
                  status_playing: "no"
                })
              }
              let tax = parseInt(gdata.coins) * 0.06;
              let total = parseInt(gdata.coins) - parseInt(tax);
              datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
              await datacoinsusr2st.save()
              datacoinsusr1st.status_playing = "no"
              await datacoinsusr1st.save()
              datacoinsusr2st.status_playing = "no"
              await datacoinsusr2st.save()
              await takribi.findOneAndDelete({
                msgID: gdata.msgID,
                idstusr: stusrgame.id
              })
              await tkusr.findOneAndDelete({
                id: stusrgame.id,
                msgID: interaction.message.id
              })
              await tkusr.findOneAndDelete({
                id: wthusrgame.id,
                msgID: interaction.message.id
              })
              await game.findOneAndDelete({
                id: stusrgame.id,
                with: wthusrgame.id,
                msgID: interaction.message.id
              })
              return;
            }
          }, 1500)

          return;
        }
      }

      if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
        if (data.notrole == stusrgame.id) {
          data.role = stusrgame.id;
          await data.save()
          data.notrole = wthusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          return interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
        }
        if (data.notrole == wthusrgame.id) {
          data.role = wthusrgame.id;
          await data.save()
          data.notrole = stusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          return interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
        }
      }

      if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) == 1) {
        if (data.notrole == stusrgame.id) {
          data.role = stusrgame.id;
          await data.save()
          data.notrole = wthusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> **Playing..**` }, { name: `${wthusrgame.tag}`, value: `> Done` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${stusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          return interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
        }
        if (data.notrole == wthusrgame.id) {
          data.role = wthusrgame.id;
          await data.save()
          data.notrole = stusrgame.id;
          await data.save()
          let embed_finish_tk_game = new Discord.MessageEmbed()
            .setTitle("بيانات التحدي")
            .setDescription(`اقصى رقم : **${dataup.max_number}**`)
            .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> **Playing..**` })
          let button_arkam1 = new MessageButton()
            .setCustomId(`arkam1tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
            .setStyle("PRIMARY")
          let button_finish = new MessageButton()
            .setCustomId(`finishtk_${gdata.msgID}`)
            .setLabel("finish")
            .setStyle("SUCCESS")
          let button_arkam2 = new MessageButton()
            .setCustomId(`arkam2tk_${gdata.msgID}`)
            .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
            .setStyle("PRIMARY")
          let row = new MessageActionRow()
            .setComponents(button_arkam1, button_finish, button_arkam2)
          client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> ${wthusrgame}\n اصبح دورك !`, components: [row] })).catch(err => console.error(err))
          return interaction.editReply({
            content: `لقد حصلت على **${urnum}**
            اصبح مجموعك ${datausrup.result}\n
            > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
          })
        }
        return;
      }





      if ((parseInt(data.max_number) < parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
        interaction.editReply({
          content: `لقد حصلت على **${urnum}**
  اصبح مجموعك ${datausrup.result}\n
  > يا للأسف , لقد تخطيت الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
        })
        let embed_finish_tk_game = new Discord.MessageEmbed()
          .setTitle("بيانات التحدي")
          .setDescription(`اقصى رقم : **${dataup.max_number}**`)
          .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
        let button_arkam1 = new MessageButton()
          .setCustomId(`arkam1tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let button_finish = new MessageButton()
          .setCustomId(`finishtk_${gdata.msgID}`)
          .setLabel("finish")
          .setStyle("SUCCESS")
          .setDisabled()
        let button_arkam2 = new MessageButton()
          .setCustomId(`arkam2tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let row = new MessageActionRow()
          .setComponents(button_arkam1, button_finish, button_arkam2)
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
        setTimeout(async () => {
          if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
           const d = await Data.findOne({ _id: wthusrgame.id });
const coinsToAdd = parseInt(gdata.coins);
if (d?.f) {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: d.f + 1, e: (d.e + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: wthusrgame.id }, { f: 1, e: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

const d1 = await Data.findOne({ _id: stusrgame.id });
if (d1?.k) {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: d1.k + 1, c: (d1.c + coinsToAdd).toLocaleString() }).then(async () => {
  });
} else {
  await Data.findOneAndUpdate({ _id: stusrgame.id }, { k: 1, c: coinsToAdd.toLocaleString() }).then(async () => {
  });
}

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
        }, 1500)
        return;
      }
      if ((parseInt(data.max_number) == parseInt(datausrup.result)) && parseInt(dataup.number_players_done) >= 2) {
        interaction.editReply({
          content: `لقد حصلت على **${urnum}**
          اصبح مجموعك ${datausrup.result}\n
          > تهانينا لقد حصلت على الرقم المطلوب و قد تم انهاء دورك`, ehpemeral: true
        })
        let embed_finish_tk_game = new Discord.MessageEmbed()
          .setTitle("بيانات التحدي")
          .setDescription(`اقصى رقم : **${dataup.max_number}**`)
          .addFields({ name: `${stusrgame.tag}`, value: `> Done` }, { name: `${wthusrgame.tag}`, value: `> Done` })
        let button_arkam1 = new MessageButton()
          .setCustomId(`arkam1tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_smaller1} - ${dataup.number_smaller2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let button_finish = new MessageButton()
          .setCustomId(`finishtk_${gdata.msgID}`)
          .setLabel("finish")
          .setStyle("SUCCESS")
          .setDisabled()
        let button_arkam2 = new MessageButton()
          .setCustomId(`arkam2tk_${gdata.msgID}`)
          .setLabel(`${dataup.number_greater1} - ${dataup.number_greater2}`)
          .setStyle("PRIMARY")
          .setDisabled()
        let row = new MessageActionRow()
          .setComponents(button_arkam1, button_finish, button_arkam2)
        client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game], content: `> انتهى التحدي...`, components: [row] })).catch(err => console.error(err))
        setTimeout(async () => {
          if (parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) > parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) < parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) || (parseInt(datausrtk1.result) == parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame} **/** ${wthusrgame} تعادل !\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            const d = await Data.findOne({ _id: stusrgame.id })
            if (d.t1) {
                await Data.findOneAndUpdate({ _id: stusrgame.id }, { t1: d.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  stusrgame.id, }, { t1: 1 }).then(() => {

                })
            }
            const d1 = await Data.findOne({ _id: wthusrgame.id })
            if (d1.t1) {
                await Data.findOneAndUpdate({ _id: wthusrgame.id }, { t1: d1.t1+1}).then(() => {
                })
            } else {
                await Data.findOneAndUpdate({ _id:  wthusrgame.id }, { t1: 1 })
            }
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if (parseInt(dataup.max_number) > parseInt(datausrtk1.result) && parseInt(dataup.max_number) < parseInt(datausrtk2.result)) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })

            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk1.result)) && (parseInt(datausrtk1.result) > parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${stusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk1.result} نقطة!\n\n${wthusrgame} خاسر ب مجموع **${datausrtk2.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) + parseInt(total)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) - parseInt(gdata.coins)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
          if ((parseInt(dataup.max_number) >= parseInt(datausrtk2.result)) && (parseInt(datausrtk1.result) < parseInt(datausrtk2.result))) {
            let embed_finish_tk_game_tm = new Discord.MessageEmbed()
              .setTitle("بيانات التحدي")
              .setDescription(`اقصى رقم : **${dataup.max_number}**`)
              .addFields({ name: `${stusrgame.tag}`, value: `> ${datausrtk1.numbers.join(" + ") || ""} = **${datausrtk1.result || 0}**` }, { name: `${wthusrgame.tag}`, value: `> ${datausrtk2.numbers.join(" + ") || ""} = **${datausrtk2.result || 0}**` })
            client.channels.cache.get(interaction.channel.id).messages.fetch(gdata.msgID).then(msg1 => msg1.edit({ embeds: [embed_finish_tk_game_tm], content: `${wthusrgame}  ** الـ ** فـآئز ** : بـ ** مجموع ** :${datausrtk2.result} نقطة!\n\n${stusrgame} خاسر ب مجموع **${datausrtk1.result}** نقطة!\nاللعبة: **الرقم التقريبي**, المبلغ: **${parseInt(gdata.coins).toLocaleString()}**`, components: [] })).catch(err => console.error(err))
            let datacoinsusr1st = await db.findOne({
              id: stusrgame.id
            })
            if (!datacoinsusr1st) {
              datacoinsusr1st = await db.create({
                id: stusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            datacoinsusr1st.coins = parseInt(datacoinsusr1st.coins) - parseInt(gdata.coins)
            await datacoinsusr1st.save()
            let datacoinsusr2st = await db.findOne({
              id: wthusrgame.id
            })
            if (!datacoinsusr2st) {
              datacoinsusr = await db.create({
                id: wthusrgame.id,
                coins: 0,
                status_playing: "no"
              })
            }
            let tax = parseInt(gdata.coins) * 0.06;
            let total = parseInt(gdata.coins) - parseInt(tax);
            datacoinsusr2st.coins = parseInt(datacoinsusr2st.coins) + parseInt(total)
            await datacoinsusr2st.save()
            datacoinsusr1st.status_playing = "no"
            await datacoinsusr1st.save()
            datacoinsusr2st.status_playing = "no"
            await datacoinsusr2st.save()
            await takribi.findOneAndDelete({
              msgID: gdata.msgID,
              idstusr: stusrgame.id
            })
            await tkusr.findOneAndDelete({
              id: stusrgame.id,
              msgID: interaction.message.id
            })
            await tkusr.findOneAndDelete({
              id: wthusrgame.id,
              msgID: interaction.message.id
            })
            await game.findOneAndDelete({
              id: stusrgame.id,
              with: wthusrgame.id,
              msgID: interaction.message.id
            })
            return;
          }
        }, 1500)
        return;
      }
      return interaction.editReply({
        content: `   لقد حصلت على **${urnum}**
اصبح مجموعك ${datausrup.result}
||تنبيه: انتبه ان يصبح.  مجموعك اعلى من الرقم المطلوب،  يمكنك انهاء دورك بالضغط على الزر الاخضر||`, ephemeral: true
      })
    }
  }
})



  function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }




const minesweeper = require('discord.js-minesweeper');

module.exports = {
  name: 'minesweeper',
  description: 'Play minesweeper game in Discord',
  async execute(interaction) {
    const mines = new minesweeper({
      rows: 10,
      columns: 10,
      mines: 10,
      revealFirstCell: true,
      emote: 'boom',
    });

    await mines.start();
    const grid = mines.print();

    const rows = [];
    for (let i = 0; i < grid.length; i += 1) {
      const row = new MessageActionRow();
      for (let j = 0; j < grid[i].length; j += 1) {
        const button = new MessageButton()
          .setCustomId(`${i},${j}`)
          .setLabel(' ')
          .setStyle('PRIMARY');

        row.addComponents(button);
      }
      rows.push(row);
    }

    const message = await interaction.reply({
      content: 'Minesweeper started!',
      components: rows,
    });

    const filter = (i) => i.customId.split(',')[0] === '0';

    const collector = message.createMessageComponentCollector({ filter, time: 30000 });

    collector.on('collect', (i) => {
      const [row, column] = i.customId.split(',');

      const result = mines.revealCell(row, column);

      if (result === false) {
        i.reply({
          content: 'Game Over!',
          components: [],
        });
        collector.stop();
      } else {
        const newGrid = mines.print();

        const newRows = [];
        for (let i = 0; i < newGrid.length; i += 1) {
          const row = new MessageActionRow();
          for (let j = 0; j < newGrid[i].length; j += 1) {
            const button = new MessageButton()
              .setCustomId(`${i},${j}`)
              .setLabel(newGrid[i][j] === '0' ? ' ' : newGrid[i][j])
              .setStyle('PRIMARY');

            row.addComponents(button);
          }
          newRows.push(row);
        }

        i.update({
          components: newRows,
        });
      }
    });

    collector.on('end', () => {
      const newGrid = mines.print();

      const newRows = [];
      for (let i = 0; i < newGrid.length; i += 1) {
        const row = new MessageActionRow();
        for (let j = 0; j < newGrid[i].length; j += 1) {
          const button = new MessageButton()
            .setCustomId(`${i},${j}`)
            .setLabel(newGrid[i][j] === '0' ? ' ' : newGrid[i][j])
            .setStyle('PRIMARY')
            .setDisabled();

          row.addComponents(button);
        }
        newRows.push(row);
      }

      message.edit({
        content: 'Game Over!',
        components: newRows,
      });
    });
  },
};

  client.login("MTI1MTY0NzAzMzYxNDQwMTY3OA.GloRLS.tIzaG2kN9_-qAcdExxvVjucqsQtBPOYBw_Iq_s")